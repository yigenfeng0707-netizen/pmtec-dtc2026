"""
PMTEC gRPC Server - Implements DTB Model four services.
DTB Model: WarEngine (simulation) + BattleNetwork (tracks) + ApplicationStore (capabilities) + PlugAndPlay (discovery)
ASDA: Full cycle (Act->Sense->Decide->Adapt) executed each simulation cycle.
"""

import sys
import os
import json
import time
import math
import random
import threading
import uuid
from concurrent import futures
from typing import Optional

# Add generated proto path
_GEN_DIR = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "proto", "generated"
)
if _GEN_DIR not in sys.path:
    sys.path.insert(0, _GEN_DIR)

import grpc
import dtb_model_pb2 as pb
import dtb_model_pb2_grpc as pb_grpc

# Add project root to path
_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

from config import (
    GRPC_HOST,
    GRPC_PORT,
    SIM_TICK_SECONDS,
    SIM_DURATION_SECONDS,
    SIM_RANDOM_SEED,
    ASDA_CYCLE_SECONDS,
    ASDA_PHASES,
    BASES_GEOJSON,
    OUTPUT_DIR,
    DTB_COMPONENTS,
    AIRCRAFT_SPEED_KMH,
)
from core.event_bus import EventBus, Event
from core.simulation_clock import SimulationClock
from core.lvc_architecture import LVCArchitecture, haversine
from models.entity import AircraftEntity, MissileEntity, SensorEntity, BattlefieldEntity
from models.track import TrackManager, Track
from services.spear_replay import SpearReplay


class PMTECEngine:
    """Core PMTEC simulation engine - drives the ASDA loop."""

    def __init__(self):
        self.clock = SimulationClock(SIM_TICK_SECONDS)
        self.event_bus = EventBus()
        self.lvc = LVCArchitecture()
        self.track_mgr = TrackManager()
        self.spear = SpearReplay()
        self.asda_phase_idx = 0
        self.asda_cycle_count = 0
        self.scenario_name = ""
        self.duration = SIM_DURATION_SECONDS
        self._running = False
        self._thread: Optional[threading.Thread] = None
        self._stop_flag = threading.Event()
        self._bases: list[dict] = []
        self._entities: list[BattlefieldEntity] = []
        self._sensors: list[SensorEntity] = []
        self._missiles: list[MissileEntity] = []
        self._app_store: dict[str, dict] = {}
        self._components: dict[str, dict] = {}
        self._start_time: float = 0
        self._init_app_store()
        self._init_components()
        random.seed(SIM_RANDOM_SEED)

    def _init_app_store(self):
        """Initialize the DTB Application Store with capability modules."""
        apps = [
            (
                "app-f35-strike",
                "F-35A Strike Package",
                "v2.1",
                "strike",
                "Stealth strike mission planning with sensor fusion and threat avoidance",
            ),
            (
                "app-iamd-defense",
                "IAMD Integrated Air Defense",
                "v3.0",
                "defense",
                "Multi-layer air defense: PAC-3, THAAD, Aegis coordination via C2BMC",
            ),
            (
                "app-isr-collection",
                "ISR Sensor Collection",
                "v1.8",
                "isr",
                "Multi-INT sensor tasking: SIGINT, GEOINT, MASINT fusion and tipper-cueing",
            ),
            (
                "app-ace-dispersal",
                "ACE Agile Combat Employment",
                "v2.5",
                "logistics",
                "Distributed aircraft dispersal algorithm with risk-weighted basing",
            ),
            (
                "app-spear-replay",
                "SPEAR Replay Analysis",
                "v1.2",
                "analysis",
                "Post-action review with event timeline reconstruction and ASDA metrics",
            ),
            (
                "app-jad-ai",
                "JAD-AI Joint All-Domain AI",
                "v0.9-beta",
                "decision",
                "AI-assisted decision support across all domains with human-on-the-loop",
            ),
        ]
        for app_id, name, ver, cat, desc in apps:
            self._app_store[app_id] = {
                "app_id": app_id,
                "name": name,
                "version": ver,
                "category": cat,
                "description": desc,
            }

    def _init_components(self):
        """Initialize Plug-and-Play registered components."""
        components = [
            (
                "comp-sim-core",
                "simulation_engine",
                "pmtec://sim:50051",
                {"framework": "PMTEC", "lvc": "all"},
            ),
            (
                "comp-track-fusion",
                "track_manager",
                "pmtec//track:50051",
                {"fusion": "kinematic", "sources": "multi"},
            ),
            (
                "comm-grpc-bridge",
                "grpc_interface",
                "pmtec//grpc:50051",
                {"proto": "dtb_model.proto", "services": "4"},
            ),
            (
                "comp-asda-loop",
                "decision_engine",
                "pmtec//asda:50051",
                {"cycle_s": str(ASDA_CYCLE_SECONDS), "phases": "4"},
            ),
        ]
        for comp_id, comp_type, endpoint, meta in components:
            self._components[comp_id] = {
                "component_id": comp_id,
                "component_type": comp_type,
                "endpoint": endpoint,
                "metadata": meta,
            }

    def load_bases(self, geojson_path: str = None):
        """Load base data from GeoJSON (Level 1 data)."""
        import re

        path = geojson_path or BASES_GEOJSON
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        self._bases = []
        # Match aircraft designations: F-35A, KC-135, B-1B, CV-22, F/A-18, etc.
        ac_pattern = re.compile(r"\b([A-Z]{1,3}[-/]\d+[A-Z]?)\b")
        for feat in data.get("features", []):
            props = feat.get("properties", {})
            coords = feat.get("geometry", {}).get("coordinates", [0, 0])
            # Parse aircraft string to list of types
            aircraft_str = props.get("aircraft", "")
            found = ac_pattern.findall(aircraft_str) if aircraft_str else []
            # Normalize common types: F-35 -> F-35A, F-16 -> F-16C, F-22 -> F-22A
            normalize = {
                "F-35": "F-35A",
                "F-35B": "F-35A",
                "F-16": "F-16C",
                "F-22": "F-22A",
                "F-15": "F-15C",
            }
            aircraft_types = list(set(normalize.get(t, t) for t in found))
            base = {
                "id": props.get("id", props.get("name", "")),
                "name": props.get("name", ""),
                "lat": coords[1] if len(coords) >= 2 else props.get("lat", 0),
                "lon": coords[0] if len(coords) >= 2 else props.get("lon", 0),
                "region": props.get("region", ""),
                "military_branch": props.get("branch", ""),
                "is_ace_hub": props.get("ace_hub", False),
                "aircraft_types": aircraft_types,
                "sensor_types": ["AN/TPS-80"],
            }
            self._bases.append(base)
        return len(self._bases)

    def setup_scenario(self, scenario_name: str = "PMTEC-Pacific"):
        """Initialize the battlefield with entities from base data."""
        self.scenario_name = scenario_name
        if not self._bases:
            self.load_bases()

        # Create Live layer: sensors at each base
        for base in self._bases:
            for sensor_type in base.get("sensor_types", ["AN/TPS-80"]):
                sensor = SensorEntity(
                    sensor_type=sensor_type,
                    lat=base["lat"],
                    lon=base["lon"],
                    base_id=base["id"],
                    detection_range_km=400,
                )
                self.lvc.live.add_entity(sensor)
                self._sensors.append(sensor)

        # Create Virtual layer: aircraft at ACE hubs
        ace_hubs = [b for b in self._bases if b.get("is_ace_hub")]
        for base in ace_hubs:
            for ac_type in base.get("aircraft_types", ["F-35A"]):
                count = 4 if ac_type.startswith("F-3") else 2
                for i in range(count):
                    ac = AircraftEntity(
                        ac_type=ac_type,
                        base_id=base["id"],
                        lat=base["lat"] + random.uniform(-0.05, 0.05),
                        lon=base["lon"] + random.uniform(-0.05, 0.05),
                        callsign=f"{base['id'][:4].upper()}{ac_type[:3]}{i + 1:02d}",
                    )
                    ac.assign_mission("patrol")
                    self.lvc.virtual.add_entity(ac)
                    self._entities.append(ac)

        # Create Constructive layer: high-level command entities
        cmd_entity = BattlefieldEntity(
            id="CMD-INDOPACOM",
            entity_type="command",
            subtype="JOC",
            lat=21.35,
            lon=-157.96,  # INDOPACOM HQ Honolulu
            affiliation="friendly",
            status="active",
        )
        self.lvc.constructive.add_entity(cmd_entity)
        self._entities.append(cmd_entity)

        # Record initial state
        self.spear.record_snapshot(self.get_state_dict())

    def start_simulation(self, scenario_name: str, duration: int, seed: int):
        """Start the PMTEC simulation."""
        if self._running:
            return False, "Simulation already running"

        random.seed(seed)
        self.duration = duration or SIM_DURATION_SECONDS
        self.setup_scenario(scenario_name)

        self._running = True
        self._stop_flag.clear()
        self.clock.start()
        self._start_time = time.time()

        # Start simulation thread
        self._thread = threading.Thread(target=self._run_loop, daemon=True)
        self._thread.start()

        self._emit_event(
            "sim_start",
            "system",
            "PMTEC simulation started",
            {
                "scenario": scenario_name,
                "duration": duration,
                "seed": seed,
                "asda_phase": "Act",
                "lvc_layer": "Constructive",
            },
        )
        return True, f"Simulation started: {scenario_name}"

    def stop_simulation(self):
        """Stop the simulation."""
        if not self._running:
            return False, "Simulation not running"
        self._stop_flag.set()
        self._running = False
        self.clock.stop()
        if self._thread:
            self._thread.join(timeout=5)
        self._emit_event(
            "sim_stop",
            "system",
            "PMTEC simulation stopped",
            {
                "total_cycles": self.clock.current.cycle_count,
                "asda_phase": "Adapt",
                "lvc_layer": "Constructive",
            },
        )
        return True, "Simulation stopped"

    def _run_loop(self):
        """Main simulation loop - executes ASDA cycle."""
        tick_count = 0
        while (
            not self._stop_flag.is_set()
            and self.clock.current.sim_seconds < self.duration
        ):
            self.clock.tick()
            tick_count += 1

            # ASDA cycle every ASDA_CYCLE_SECONDS
            if tick_count % int(ASDA_CYCLE_SECONDS / SIM_TICK_SECONDS) == 0:
                self._execute_asda_cycle()

            # Update entities every tick
            self._update_entities(SIM_TICK_SECONDS)

            # Update tracks every 5 ticks
            if tick_count % 5 == 0:
                self._update_tracks()

            # Record snapshot every 10 ticks
            if tick_count % 10 == 0:
                self.spear.record_snapshot(self.get_state_dict())

            # Record metrics
            self.spear.record_metric("active_entities", len(self._active_entities()))
            self.spear.record_metric("active_tracks", len(self.track_mgr.active_tracks))
            self.spear.record_metric("network_vuln", self._calc_network_vulnerability())

            # Sleep for real-time pacing
            time.sleep(0.01)  # fast simulation

        self._running = False

    def _execute_asda_cycle(self):
        """Execute one ASDA (Act-Sense-Decide-Adapt) cycle."""
        phase = ASDA_PHASES[self.asda_phase_idx]
        self.asda_phase_idx = (self.asda_phase_idx + 1) % len(ASDA_PHASES)
        self.asda_cycle_count += 1

        if phase == "Act":
            self._asda_act()
        elif phase == "Sense":
            self._asda_sense()
        elif phase == "Decide":
            self._asda_decide()
        elif phase == "Adapt":
            self._asda_adapt()

        self._emit_event(
            "asda_cycle",
            "ASDA-Engine",
            f"ASDA cycle {self.asda_cycle_count}: {phase} phase",
            {
                "cycle": self.asda_cycle_count,
                "phase": phase,
                "lvc_layer": "Constructive",
            },
        )

    def _asda_act(self):
        """Act phase: execute current orders, missile launches, deployments."""
        # Random missile launch from hostile forces
        if random.random() < 0.30 and self._bases:
            target_base = random.choice(self._bases)
            launch_lat = target_base["lat"] + random.uniform(
                -2, -5
            )  # 220-550km from target
            launch_lon = target_base["lon"] + random.uniform(-5, -2)
            missile_type = random.choice(["DF-21D", "DF-26", "DF-17"])
            missile = MissileEntity(
                missile_type,
                launch_lat,
                launch_lon,
                target_base["lat"],
                target_base["lon"],
            )
            self.lvc.virtual.add_entity(missile)
            self._missiles.append(missile)
            self._entities.append(missile)
            self._emit_event(
                "missile_launch",
                "hostile",
                f"{missile_type} launched toward {target_base['name']}",
                {
                    "missile_type": missile_type,
                    "target": target_base["id"],
                    "lvc_layer": "Virtual",
                },
            )

        # ACE dispersal: move some aircraft to alternate bases
        if random.random() < 0.2 and len(self._bases) > 1:
            aircraft = [
                e
                for e in self._entities
                if isinstance(e, AircraftEntity)
                and e.status == "active"
                and e.mission == "patrol"
            ]
            if aircraft:
                ac = random.choice(aircraft)
                alt_base = random.choice(
                    [b for b in self._bases if b["id"] != ac.base_id]
                )
                ac.assign_mission("transfer", alt_base["lat"], alt_base["lon"])
                self._emit_event(
                    "transfer",
                    ac.id,
                    f"{ac.subtype} transferring from {ac.base_id} to {alt_base['id']}",
                    {
                        "from": ac.base_id,
                        "to": alt_base["id"],
                        "ac_type": ac.subtype,
                        "lvc_layer": "Virtual",
                    },
                )

    def _asda_sense(self):
        """Sense phase: run all sensors, collect tracks."""
        all_entities = self.lvc.all_entities()
        for sensor in self._sensors:
            if sensor.status == "active":
                detections = sensor.scan(all_entities)
                for det in detections:
                    self.track_mgr.add_observation(
                        lat=det["lat"],
                        lon=det["lon"],
                        alt_m=det["alt_m"],
                        heading=det["heading_deg"],
                        speed=det["speed_kmh"],
                        confidence=det["confidence"],
                        classification=det["classification"],
                        source=det["source"],
                    )
                    self._emit_event(
                        "detect",
                        sensor.id,
                        f"Sensor detected track at ({det['lat']:.2f}, {det['lon']:.2f})",
                        {
                            "confidence": det["confidence"],
                            "classification": det["classification"],
                            "lvc_layer": "Live",
                        },
                    )

    def _asda_decide(self):
        """Decide phase: evaluate threats, decide countermeasures."""
        tracks = self.track_mgr.fuse()
        hostile_tracks = [
            t
            for t in tracks.values()
            if t.classification in ("missile", "aircraft") and t.confidence > 0.5
        ]

        for track in hostile_tracks:
            # Decide: intercept or evade
            if track.classification == "missile":
                self._emit_event(
                    "intercept_decision",
                    "ASDA-Engine",
                    f"Decide: intercept hostile track {track.track_id}",
                    {
                        "track_id": track.track_id,
                        "confidence": track.confidence,
                        "asda_phase": "Decide",
                        "lvc_layer": "Constructive",
                    },
                )
            else:
                self._emit_event(
                    "evade_decision",
                    "ASDA-Engine",
                    f"Decide: evade hostile aircraft {track.track_id}",
                    {
                        "track_id": track.track_id,
                        "asda_phase": "Decide",
                        "lvc_layer": "Constructive",
                    },
                )

    def _asda_adapt(self):
        """Adapt phase: apply decisions, update deployments, learn."""
        # Check missile impacts
        for missile in self._missiles:
            if missile.status == "destroyed" and missile.impact_time > 0:
                # Assess damage at impact site
                impact_base = min(
                    self._bases,
                    key=lambda b: haversine(
                        b["lat"], b["lon"], missile.lat, missile.lon
                    ),
                )
                dist = haversine(
                    impact_base["lat"], impact_base["lon"], missile.lat, missile.lon
                )
                if dist < 5.0:  # hit the base
                    # Monte Carlo damage assessment (simplified)
                    hit_prob = min(0.8, 1.0 - (missile.cep / 1000) / max(dist, 0.1))
                    if random.random() < hit_prob:
                        # Damage nearby aircraft
                        nearby_ac = [
                            e
                            for e in self._entities
                            if isinstance(e, AircraftEntity)
                            and e.distance_to(missile.lat, missile.lon) < 5
                            and e.status == "active"
                        ]
                        for ac in nearby_ac[:2]:  # max 2 damaged
                            ac.status = "destroyed"
                            self._emit_event(
                                "damage",
                                missile.id,
                                f"{ac.subtype} {ac.id} destroyed at {impact_base['name']}",
                                {
                                    "base": impact_base["id"],
                                    "ac_type": ac.subtype,
                                    "missile_type": missile.subtype,
                                    "lvc_layer": "Virtual",
                                },
                            )
                missile.impact_time = 0  # mark as processed

        # Recover: transfer aircraft back from alternate bases
        landed = [
            e
            for e in self._entities
            if isinstance(e, AircraftEntity) and e.status == "landed"
        ]
        for ac in landed:
            if random.random() < 0.3:
                home_base = next(
                    (b for b in self._bases if b["id"] == ac.base_id), None
                )
                if home_base:
                    ac.status = "active"
                    ac.assign_mission("transfer", home_base["lat"], home_base["lon"])
                    self._emit_event(
                        "recover",
                        ac.id,
                        f"{ac.subtype} recovering to {ac.base_id}",
                        {
                            "ac_type": ac.subtype,
                            "to": ac.base_id,
                            "lvc_layer": "Virtual",
                        },
                    )

    def _update_entities(self, dt: float):
        """Update all entity positions."""
        for entity in self._entities:
            if isinstance(entity, AircraftEntity):
                entity.update(dt)
            elif isinstance(entity, MissileEntity):
                entity.update(dt)

        # Clean up destroyed missiles from all lists
        active_missiles = [m for m in self._missiles if m.status == "active"]
        destroyed = [m for m in self._missiles if m.status != "active"]
        for m in destroyed:
            self.lvc.virtual.remove_entity(m.id)
        self._missiles = active_missiles
        # Also clean up destroyed aircraft from entities list for display
        self._entities = [
            e
            for e in self._entities
            if e.status not in ("destroyed",) or isinstance(e, AircraftEntity)
        ]

    def _update_tracks(self):
        """Fuse and update track picture."""
        self.track_mgr.fuse()

    def _calc_network_vulnerability(self) -> float:
        """Calculate network vulnerability score (0=secure, 1=critical)."""
        active = len(self._active_entities())
        destroyed = len([e for e in self._entities if e.status == "destroyed"])
        if active + destroyed == 0:
            return 0.0
        return min(1.0, destroyed / max(active + destroyed, 1) * 2)

    def _active_entities(self) -> list:
        return [e for e in self._entities if e.status == "active"]

    def _emit_event(
        self, event_type: str, source: str, description: str, data: dict = None
    ):
        """Emit and record a simulation event."""
        evt = Event(
            event_type=event_type,
            timestamp=time.time(),
            source=source,
            data=data or {},
        )
        self.event_bus.publish(evt)
        evt_dict = evt.to_dict()
        evt_dict["description"] = description
        self.spear.record_event(evt_dict)

    def get_state_dict(self) -> dict:
        """Get current system state as dictionary."""
        return {
            "sim_time": str(self.clock.current),
            "sim_seconds": self.clock.current.sim_seconds,
            "total_entities": len(self._entities),
            "active_tracks": len(self.track_mgr.active_tracks),
            "asda_cycle": self.asda_cycle_count,
            "asda_phase": ASDA_PHASES[(self.asda_phase_idx - 1) % 4]
            if self.asda_cycle_count > 0
            else "idle",
            "network_vulnerability": round(self._calc_network_vulnerability(), 3),
            "entities": [e.to_dict() for e in self._entities if e.status == "active"],
            "tracks": [t.to_dict() for t in self.track_mgr.active_tracks],
        }

    # ---- gRPC service implementations ----

    def get_state_proto(self, at_time: int = 0) -> pb.SystemState:
        """Convert state to protobuf message."""
        state = self.get_state_dict()
        msg = pb.SystemState(
            sim_time=int(state["sim_seconds"]),
            total_entities=state["total_entities"],
            active_tracks=state["active_tracks"],
            asda_cycle=state["asda_cycle"],
            asda_phase=state["asda_phase"],
            network_vulnerability=state["network_vulnerability"],
            strike_capability=len(
                [
                    e
                    for e in self._entities
                    if isinstance(e, AircraftEntity) and e.status == "active"
                ]
            ),
        )
        for e_dict in state["entities"]:
            msg.entities.add(
                id=e_dict["id"],
                type=e_dict["type"],
                subtype=e_dict["subtype"],
                lat=e_dict["lat"],
                lon=e_dict["lon"],
                alt_m=e_dict["alt_m"],
                heading_deg=e_dict["heading"],
                speed_kmh=e_dict["speed_kmh"],
                affiliation=e_dict["affiliation"],
                base_id=e_dict["base_id"],
                status=e_dict["status"],
            )
        for t_dict in state["tracks"]:
            msg.tracks.add(
                track_id=t_dict["track_id"],
                lat=t_dict["lat"],
                lon=t_dict["lon"],
                alt_m=t_dict["alt_m"],
                heading_deg=t_dict["heading"],
                speed_kmh=t_dict["speed_kmh"],
                confidence=t_dict["confidence"],
                classification=t_dict["classification"],
            )
        # Recent events (last 10)
        for evt in self.spear.events[-10:]:
            sim_evt = msg.recent_events.add(
                event_id=evt.get("event_id", ""),
                event_type=evt.get("event_type", ""),
                timestamp=int(evt.get("timestamp", 0)),
                actor=evt.get("source", ""),
                description=evt.get("description", ""),
            )
            for k, v in evt.get("data", {}).items():
                if isinstance(v, (str, int, float)):
                    sim_evt.params[str(k)] = str(v)
        return msg


class WarEngineServicer(pb_grpc.WarEngineServicer):
    """DTB WarEngine service - simulation control."""

    def __init__(self, engine: PMTECEngine):
        self.engine = engine

    def StartSimulation(self, request, context):
        success, msg = self.engine.start_simulation(
            request.scenario_name, request.duration_seconds, request.seed
        )
        return pb.Ack(success=success, message=msg)

    def StopSimulation(self, request, context):
        success, msg = self.engine.stop_simulation()
        return pb.Ack(success=success, message=msg)

    def GetState(self, request, context):
        return self.engine.get_state_proto(request.at_time)

    def InjectEvent(self, request, context):
        self.engine._emit_event(
            request.event_type, request.actor, request.description, dict(request.params)
        )
        return pb.Ack(success=True, message=f"Event {request.event_id} injected")

    def GetSpearReport(self, request, context):
        report = self.engine.spear.generate_report(request.start_time, request.end_time)
        msg = pb.SpearReport(
            total_duration=int(report["total_duration_s"]),
            total_events=int(report["total_events"]),
            total_tracks=int(len(self.engine.track_mgr.tracks)),
            summary=report["summary"],
        )
        for evt in report.get("timeline", []):
            msg.timeline.add(
                event_id=str(evt.get("event_id", "")),
                event_type=str(evt.get("event_type", "")),
                timestamp=int(float(evt.get("timestamp", 0))),
                actor=str(evt.get("source", "")),
                description=str(evt.get("description", "")),
            )
        return msg


class BattleNetworkServicer(pb_grpc.BattleNetworkServicer):
    """DTB BattleNetwork service - track and entity management."""

    def __init__(self, engine: PMTECEngine):
        self.engine = engine

    def GetTrackFeed(self, request, context):
        """Stream track updates to subscribers."""
        last_count = 0
        while self.engine._running or context.is_active():
            tracks = self.engine.track_mgr.active_tracks
            if len(tracks) != last_count:
                update = pb.TrackUpdate(timestamp=int(time.time()))
                for t in tracks:
                    if (
                        request.min_lat <= t.lat <= request.max_lat
                        and request.min_lon <= t.lon <= request.max_lon
                    ):
                        if (
                            not request.classification_filter
                            or t.classification == request.classification_filter
                        ):
                            update.tracks.add(
                                track_id=t.track_id,
                                lat=t.lat,
                                lon=t.lon,
                                alt_m=t.alt_m,
                                heading_deg=t.heading_deg,
                                speed_kmh=t.speed_kmh,
                                confidence=t.confidence,
                                classification=t.classification,
                            )
                yield update
                last_count = len(tracks)
            time.sleep(1)

    def GetEntityStatus(self, request, context):
        """Get status of a specific entity."""
        for entity in self.engine._entities:
            if request.entity_id and entity.id != request.entity_id:
                continue
            if request.type_filter and entity.entity_type != request.type_filter:
                continue
            return pb.EntityStatus(
                entity=pb.Entity(
                    id=entity.id,
                    type=entity.entity_type,
                    subtype=entity.subtype,
                    lat=entity.lat,
                    lon=entity.lon,
                    alt_m=entity.alt_m,
                    heading_deg=entity.heading_deg,
                    speed_kmh=entity.speed_kmh,
                    affiliation=entity.affiliation,
                    base_id=entity.base_id,
                    status=entity.status,
                ),
                health="operational" if entity.status == "active" else entity.status,
                fuel_pct=getattr(entity, "fuel_pct", 1.0),
                ammo_count=getattr(entity, "ammo_count", 0),
            )
        return pb.EntityStatus()

    def GetNetworkState(self, request, context):
        """Get DTB BattleNetwork state."""
        active = len(self.engine._active_entities())
        total = len(self.engine._entities)
        degraded = total - active
        node_statuses = []
        for base in self.engine._bases[:10]:
            ac_count = len(
                [
                    e
                    for e in self.engine._entities
                    if isinstance(e, AircraftEntity) and e.base_id == base["id"]
                ]
            )
            node_statuses.append(
                f"{base['id']}: {ac_count} aircraft, {'active' if ac_count > 0 else 'empty'}"
            )
        return pb.NetworkState(
            total_nodes=len(self.engine._bases),
            active_nodes=len(
                [
                    b
                    for b in self.engine._bases
                    if any(
                        e.base_id == b["id"] and e.status == "active"
                        for e in self.engine._entities
                    )
                ]
            ),
            degraded_nodes=degraded,
            avg_latency_ms=round(random.uniform(15, 50), 1),
            node_status=node_statuses,
        )


class ApplicationStoreServicer(pb_grpc.ApplicationStoreServicer):
    """DTB ApplicationStore service - capability management."""

    def __init__(self, engine: PMTECEngine):
        self.engine = engine

    def ListApps(self, request, context):
        msg = pb.AppList()
        for app_id, app in self.engine._app_store.items():
            if request.category and app["category"] != request.category:
                continue
            msg.apps.add(
                app_id=app["app_id"],
                name=app["name"],
                version=app["version"],
                category=app["category"],
                description=app["description"],
            )
        return msg

    def DeployApp(self, request, context):
        app = self.engine._app_store.get(request.app_id)
        if not app:
            return pb.DeployResult(
                success=False, message=f"App {request.app_id} not found"
            )
        deploy_id = f"DEP-{uuid.uuid4().hex[:8]}"
        self.engine._emit_event(
            "deploy",
            "ApplicationStore",
            f"App {app['name']} deployed to {request.target_base} x{request.count}",
            {
                "app_id": request.app_id,
                "base": request.target_base,
                "count": request.count,
                "lvc_layer": "Constructive",
            },
        )
        return pb.DeployResult(
            success=True,
            message=f"{app['name']} v{app['version']} deployed to {request.target_base}",
            deployment_id=deploy_id,
        )

    def QueryCapability(self, request, context):
        base = next((b for b in self.engine._bases if b["id"] == request.base_id), None)
        if not base:
            return pb.CapabilityReport(base_id=request.base_id)
        ac_list = [
            e
            for e in self.engine._entities
            if isinstance(e, AircraftEntity)
            and e.base_id == base["id"]
            and e.status == "active"
        ]
        strike = sum(
            1
            for a in ac_list
            if a.subtype.startswith("F-3") or a.subtype.startswith("F-15")
        )
        defense = len([s for s in self.engine._sensors if s.base_id == base["id"]])
        isr = len([a for a in ac_list if a.subtype in ("RC-135", "E-3")])
        logistics = len([a for a in ac_list if a.subtype.startswith("KC-")])
        return pb.CapabilityReport(
            base_id=base["id"],
            strike_capability=strike,
            defense_capability=defense,
            isr_capability=isr,
            logistics_capability=logistics,
        )


class PlugAndPlayServicer(pb_grpc.PlugAndPlayServicer):
    """DTB PlugAndPlay service - component registration and discovery."""

    def __init__(self, engine: PMTECEngine):
        self.engine = engine

    def RegisterComponent(self, request, context):
        comp_id = request.component_id or f"comp-{uuid.uuid4().hex[:8]}"
        self.engine._components[comp_id] = {
            "component_id": comp_id,
            "component_type": request.component_type,
            "endpoint": request.endpoint,
            "metadata": dict(request.metadata),
        }
        return pb.RegResult(
            success=True,
            component_id=comp_id,
            message=f"Component {comp_id} registered as {request.component_type}",
        )

    def DiscoverServices(self, request, context):
        msg = pb.ServiceList()
        for comp_id, comp in self.engine._components.items():
            if request.service_type and comp["component_type"] != request.service_type:
                continue
            msg.services.add(
                service_id=comp_id,
                service_type=comp["component_type"],
                endpoint=comp["endpoint"],
                healthy=True,
            )
        return msg

    def HealthCheck(self, request, context):
        uptime = time.time() - self.engine._start_time if self.engine._start_time else 0
        return pb.HealthStatus(
            healthy=True,
            version="PMTEC-v1.0",
            uptime_seconds=int(uptime),
            cpu_usage=round(random.uniform(10, 40), 1),
            active_connections=len(self.engine._components),
        )


class PMTECServer:
    """PMTEC gRPC Server - hosts all DTB Model services."""

    def __init__(self, host: str = GRPC_HOST, port: int = GRPC_PORT):
        self.host = host
        self.port = port
        self.engine = PMTECEngine()
        self._server: Optional[grpc.Server] = None

    def start(self):
        """Start the gRPC server with all DTB services."""
        self._server = grpc.server(futures.ThreadPoolExecutor(max_workers=10))
        pb_grpc.add_WarEngineServicer_to_server(
            WarEngineServicer(self.engine), self._server
        )
        pb_grpc.add_BattleNetworkServicer_to_server(
            BattleNetworkServicer(self.engine), self._server
        )
        pb_grpc.add_ApplicationStoreServicer_to_server(
            ApplicationStoreServicer(self.engine), self._server
        )
        pb_grpc.add_PlugAndPlayServicer_to_server(
            PlugAndPlayServicer(self.engine), self._server
        )
        self._server.add_insecure_port(f"{self.host}:{self.port}")
        self._server.start()
        return True

    def stop(self):
        if self._server:
            self.engine.stop_simulation()
            self._server.stop(grace=2)
        return True

    def wait_for_termination(self):
        if self._server:
            self._server.wait_for_termination()

    @property
    def address(self) -> str:
        return f"{self.host}:{self.port}"
