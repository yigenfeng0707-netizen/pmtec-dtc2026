#!/usr/bin/env python3
"""
PMTEC Digital Battlefield Simulation System - DTC 2026 Level 3
Entry point: starts gRPC server, runs PMTEC scenario, generates tactical display.
DTB Model: 4 gRPC services (WarEngine, BattleNetwork, ApplicationStore, PlugAndPlay)
ASDA: Act -> Sense -> Decide -> Adapt loop
LVC: Live (sensors) + Virtual (CGF) + Constructive (command)
"""

import sys
import os
import time
import json
import argparse

# Ensure project root in path
PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from config import (
    GRPC_HOST,
    GRPC_PORT,
    SIM_DURATION_SECONDS,
    SIM_RANDOM_SEED,
    OUTPUT_DIR,
    DTB_COMPONENTS,
    ASDA_PHASES,
    ASDA_CYCLE_SECONDS,
)
from services.grpc_server import PMTECServer
from services.spear_replay import SpearReplay
from visualization.tactical_display import TacticalDisplay


def run_simulation(
    scenario_name: str = "PMTEC-Pacific",
    duration: int = SIM_DURATION_SECONDS,
    seed: int = SIM_RANDOM_SEED,
    generate_display: bool = True,
    export_report: bool = True,
    start_grpc: bool = True,
):
    """Run the PMTEC simulation."""
    print("=" * 70)
    print("PMTEC Digital Battlefield Simulation System")
    print("DTC 2026 Level 3 - Digital Twin Battlefield")
    print("=" * 70)
    print()

    # 1. Initialize PMTEC server (gRPC + simulation engine)
    server = PMTECServer(GRPC_HOST, GRPC_PORT)
    engine = server.engine

    # Load base data from Level 1
    base_count = engine.load_bases()
    print(f"[1/5] Loaded {base_count} military bases from Level 1 GeoJSON")

    # 2. Start gRPC server if requested
    if start_grpc:
        server.start()
        print(f"[2/5] gRPC server started at {server.address}")
        print(
            f"       Services: WarEngine, BattleNetwork, ApplicationStore, PlugAndPlay"
        )
        print(f"       DTB Components: {len(DTB_COMPONENTS)}")
        for name, desc in DTB_COMPONENTS.items():
            print(f"         - {name}: {desc[:50]}...")
    else:
        print("[2/5] gRPC server skipped (standalone mode)")

    # 3. Start simulation
    print(f"[3/5] Starting simulation: {scenario_name}")
    print(
        f"       Duration: {duration}s | Seed: {seed} | ASDA cycle: {ASDA_CYCLE_SECONDS}s"
    )
    print(f"       ASDA phases: {' -> '.join(ASDA_PHASES)}")
    print()

    success, msg = engine.start_simulation(scenario_name, duration, seed)
    if not success:
        print(f"ERROR: {msg}")
        return

    # 4. Monitor simulation progress
    print("[4/5] Simulation running...")
    last_cycle = 0
    last_phase = ""
    while engine._running:
        state = engine.get_state_dict()
        cycle = state["asda_cycle"]
        phase = state["asda_phase"]
        if cycle != last_cycle or phase != last_phase:
            active_entities = state["total_entities"]
            active_tracks = state["active_tracks"]
            net_vuln = state["network_vulnerability"]
            print(
                f"  T+{state['sim_seconds']:6.0f}s | ASDA#{cycle} {phase:8s} | "
                f"Entities: {active_entities:3d} | Tracks: {active_tracks:3d} | "
                f"Vuln: {net_vuln:.1%}"
            )
            last_cycle = cycle
            last_phase = phase

        # Check if simulation is done
        if state["sim_seconds"] >= duration:
            break
        time.sleep(0.5)

    # Stop simulation
    engine.stop_simulation()
    print()

    # 5. Generate outputs
    print("[5/5] Generating outputs...")
    final_state = engine.get_state_dict()

    # Generate tactical display HTML
    display_path = None
    if generate_display:
        display = TacticalDisplay()
        events_for_display = engine.spear.events[-200:]
        display_path = display.generate_html(final_state, events_for_display)
        print(f"       Tactical display: {display_path}")

    # Export SPEAR report
    report_path = None
    if export_report:
        os.makedirs(OUTPUT_DIR, exist_ok=True)
        report_path = os.path.join(OUTPUT_DIR, "pmtec_spear_report.json")
        engine.spear.export_json(report_path)
        print(f"       SPEAR report: {report_path}")

    # Also export final state
    state_path = os.path.join(OUTPUT_DIR, "pmtec_final_state.json")
    with open(state_path, "w", encoding="utf-8") as f:
        json.dump(final_state, f, indent=2, ensure_ascii=False, default=str)
    print(f"       Final state: {state_path}")

    # Stop gRPC server
    if start_grpc:
        server.stop()
        print(f"\ngRPC server stopped.")

    # Print summary
    print()
    print("=" * 70)
    print("PMTEC Simulation Complete - Summary")
    print("=" * 70)
    report = engine.spear.generate_report()
    print(f"  Simulation time: {final_state['sim_seconds']:.0f}s")
    print(f"  ASDA cycles: {final_state['asda_cycle']}")
    print(f"  Total events: {report['total_events']}")
    print(f"  Active entities: {final_state['total_entities']}")
    print(f"  Active tracks: {final_state['active_tracks']}")
    print(f"  Network vulnerability: {final_state['network_vulnerability']:.1%}")
    print()
    print("  Event distribution:")
    for evt_type, count in sorted(report["event_distribution"].items()):
        print(f"    {evt_type:25s}: {count:4d}")
    print()
    print("  ASDA phase activity:")
    for phase, count in report["asda_phase_activity"].items():
        print(f"    {phase:8s}: {count:4d} events")
    print()
    print("  DTB Model services demonstrated:")
    for name, desc in DTB_COMPONENTS.items():
        print(f"    {name}: {desc}")
    print()
    if display_path:
        print(f"  Open tactical display: file:///{display_path.replace(os.sep, '/')}")
    if report_path:
        print(f"  SPEAR report: {report_path}")
    print("=" * 70)

    return {
        "state": final_state,
        "report": report,
        "display_path": display_path,
        "report_path": report_path,
    }


def main():
    parser = argparse.ArgumentParser(
        description="PMTEC Digital Battlefield Simulation - DTC 2026 Level 3"
    )
    parser.add_argument(
        "--scenario",
        default="PMTEC-Pacific",
        help="Scenario name (default: PMTEC-Pacific)",
    )
    parser.add_argument(
        "--duration",
        type=int,
        default=SIM_DURATION_SECONDS,
        help=f"Duration in seconds (default: {SIM_DURATION_SECONDS})",
    )
    parser.add_argument(
        "--seed",
        type=int,
        default=SIM_RANDOM_SEED,
        help=f"Random seed (default: {SIM_RANDOM_SEED})",
    )
    parser.add_argument(
        "--no-grpc",
        action="store_true",
        help="Run without gRPC server (standalone mode)",
    )
    parser.add_argument(
        "--no-display", action="store_true", help="Skip tactical display generation"
    )
    parser.add_argument(
        "--no-report", action="store_true", help="Skip SPEAR report export"
    )
    args = parser.parse_args()

    run_simulation(
        scenario_name=args.scenario,
        duration=args.duration,
        seed=args.seed,
        generate_display=not args.no_display,
        export_report=not args.no_report,
        start_grpc=not args.no_grpc,
    )


if __name__ == "__main__":
    main()
