"""PMTEC System Configuration - DTC 2026 Level 3."""

import os

PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(PROJECT_ROOT, "data")
PROTO_DIR = os.path.join(PROJECT_ROOT, "proto")
GENERATED_DIR = os.path.join(PROTO_DIR, "generated")
BASES_GEOJSON = os.path.join(DATA_DIR, "bases.geojson")
OUTPUT_DIR = os.path.join(PROJECT_ROOT, "output")

# gRPC server
GRPC_HOST = "localhost"
GRPC_PORT = 50051

# Simulation parameters
SIM_TICK_SECONDS = 1.0  # simulation time step
SIM_REALTIME_RATIO = 1.0  # 1.0 = real-time, 10.0 = 10x speed
SIM_DURATION_SECONDS = 1200  # 20 minutes default scenario
SIM_RANDOM_SEED = 42

# LVC architecture
LVC_LIVE_ENABLED = True  # real-world data feeds
LVC_VIRTUAL_ENABLED = True  # computer-generated forces
LVC_CONSTRUCTIVE_ENABLED = True  # aggregate-level command sim

# SPEAR replay
SPEAR_BUFFER_SIZE = 10000  # max events in replay buffer

# ASDA loop
ASDA_CYCLE_SECONDS = 10

# Track management
TRACK_FUSION_INTERVAL_S = 5
TRACK_MAX_AGE_S = 60
TRACK_MIN_CONFIDENCE = 0.3

# Entity parameters (reuse from Level 2)
AIRCRAFT_SPEED_KMH = {
    "F-35A": 1670,
    "F-22A": 2414,
    "F-15C": 2655,
    "F-15E": 2655,
    "F-16C": 2120,
    "KC-135": 870,
    "KC-46": 870,
    "E-3": 852,
    "RC-135": 980,
}
COMBAT_RADIUS_KM = {
    "F-35A": 1100,
    "F-22A": 850,
    "F-15C": 1600,
    "F-15E": 1600,
    "F-16C": 900,
    "KC-135": 2400,
    "KC-46": 1100,
    "E-3": 1850,
    "RC-135": 4000,
}
AIRCRAFT_VALUE = {
    "F-35A": 100,
    "F-22A": 90,
    "F-15C": 60,
    "F-15E": 70,
    "F-16C": 40,
    "KC-135": 80,
    "KC-46": 85,
    "E-3": 95,
    "RC-135": 85,
}
THREAT_SPEED_KMH = {
    "DF-21D": 6000,
    "DF-26": 8000,
    "DF-17": 7000,
    "KH-101": 800,
    "CJ-10": 800,
}
THREAT_CEP_M = {
    "DF-21D": 50,
    "DF-26": 150,
    "DF-17": 30,
    "KH-101": 20,
    "CJ-10": 30,
}
THREAT_WARHEAD_KG = {
    "DF-21D": 1000,
    "DF-26": 1500,
    "DF-17": 800,
    "KH-101": 450,
    "CJ-10": 500,
}

EARTH_RADIUS_KM = 6371.0

# DTB Model mapping
DTB_COMPONENTS = {
    "WarEngine": "PMTEC simulation core - drives LVC time-space coordination",
    "BattleNetwork": "gRPC track distribution + entity status broadcast",
    "ApplicationStore": "Capability modules (F-35 strike, IAMD defense, ISR collection)",
    "PlugAndPlay": "Dynamic component registration via gRPC service discovery",
}

ASDA_PHASES = ["Act", "Sense", "Decide", "Adapt"]
