# PMTEC Digital Battlefield Simulation System

## DTC 2026 Level 3 - Digital Twin Battlefield (数字孪生战场)

### Overview

PMTEC (Pacific Multi-domain Training and Experimentation Capability) digital twin battlefield simulation system, implementing the DTB Model operational logic with full ASDA (Act-Sense-Decide-Adapt) closed-loop.

### Architecture

```
pmtec_system/
|-- proto/
|   |-- dtb_model.proto          # gRPC service definitions (4 DTB services)
|   `-- generated/               # Compiled Python gRPC stubs
|       |-- dtb_model_pb2.py     # Message definitions
|       `-- dtb_model_pb2_grpc.py # Service stubs
|-- config.py                    # System configuration
|-- core/
|   |-- event_bus.py             # Pub/sub event-driven framework
|   |-- simulation_clock.py      # Simulation time management
|   `-- lvc_architecture.py      # LVC (Live/Virtual/Constructive) layers
|-- models/
|   |-- entity.py                # Aircraft, Missile, Sensor entities
|   `-- track.py                 # Sensor fusion & track management
|-- services/
|   |-- grpc_server.py           # gRPC server + simulation engine
|   `-- spear_replay.py          # SPEAR replay & analysis
|-- visualization/
|   `-- tactical_display.py      # HTML/JS real-time tactical display
|-- data/
|   `-- bases.geojson            # Level 1 base data (22 INDOPACOM bases)
|-- output/                      # Generated simulation outputs
|-- main.py                      # CLI entry point
|-- requirements.txt
`-- README.md
```

### DTB Model Services (gRPC)

| Service | Port | Description |
|---------|------|-------------|
| WarEngine | 50051 | Simulation control: Start/Stop/GetState/InjectEvent/GetSpearReport |
| BattleNetwork | 50051 | Track management: GetTrackFeed (streaming)/GetEntityStatus/GetNetworkState |
| ApplicationStore | 50051 | Capability apps: ListApps/DeployApp/QueryCapability |
| PlugAndPlay | 50051 | Component discovery: RegisterComponent/DiscoverServices/HealthCheck |

### ASDA Closed-Loop

Each 30-second simulation cycle executes:

1. **Act**: Execute current orders, missile launches, ACE dispersal orders
2. **Sense**: Run all sensors, collect and fuse tracks from multiple sources
3. **Decide**: Evaluate threats, decide intercept/evade/transfer countermeasures
4. **Adapt**: Apply decisions, assess damage, recover assets, feed lessons back

### LVC Architecture

- **Live**: Real-world data feeds (base positions, sensor networks, actual track data)
- **Virtual**: Computer-generated forces (simulated aircraft with physics models, missile trajectories)
- **Constructive**: Aggregate command-level simulation (ASDA decisions, ACE deployment algorithms)

### Application Store

| App | Category | Description |
|-----|----------|-------------|
| F-35A Strike Package | strike | Stealth strike mission planning |
| IAMD Integrated Air Defense | defense | Multi-layer air defense coordination |
| ISR Sensor Collection | isr | Multi-INT sensor tasking and fusion |
| ACE Agile Combat Employment | logistics | Distributed aircraft dispersal |
| SPEAR Replay Analysis | analysis | Post-action review and metrics |
| JAD-AI Joint All-Domain AI | decision | AI-assisted cross-domain decision support |

### Usage

```bash
# Install dependencies
pip install grpcio grpcio-tools

# Run full simulation (with gRPC server)
python main.py

# Run standalone (no gRPC server)
python main.py --no-grpc

# Custom scenario
python main.py --scenario "Custom-Threat" --duration 600 --seed 123

# Skip display/report
python main.py --no-display --no-report
```

### Outputs

- `output/pmtec_tactical_display.html` - Interactive tactical map
- `output/pmtec_spear_report.json` - SPEAR replay analysis report
- `output/pmtec_final_state.json` - Final simulation state snapshot

### Integration with Level 1 & Level 2

- **Level 1**: Uses `bases.geojson` (22 INDOPACOM bases) for Live layer initialization
- **Level 2**: ACE deployment algorithm concepts integrated into ASDA Act phase
- **Level 3**: Full gRPC-based DTB Model with LVC, ASDA, SPEAR

### Environment

- Windows 11 + Python 3.10+
- No CUDA/NVIDIA GPU required
- gRPC: grpcio + grpcio-tools
