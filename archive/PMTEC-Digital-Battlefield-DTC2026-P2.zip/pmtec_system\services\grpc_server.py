"""
PMTEC gRPC Server - Implements DTB Model four services.
DTB Model: WarEngine (simulation) + BattleNetwork (tracks) + ApplicationStore (capabilities) + PlugAndPlay (discovery)
ASDA: Full cycle (Act->Sense->Decide->Adapt) executed each simulation cycle.
"""

import sys
import os
import json
import time
import math
import random
import threading
import uuid
from concurrent import futures
from typing import Optional

# Add generated proto path
_GEN_DIR = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "proto", "generated"
)
if _GEN_DIR not in sys.path:
    sys.path.insert(0, _GEN_DIR)

import grpc
import dtb_model_pb2 as pb
import dtb_model_pb2_grpc as pb_grpc

# Add project root to path
_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

from config import (
    GRPC_HOST,
    GRPC_PORT,
    SIM_TICK_SECONDS,
    SIM_DURATION_SECONDS,
    SIM_RANDOM_SEED,
    ASDA_CYCLE_SECONDS,
    ASDA_PHASES,
    BASES_GEOJSON,
    OUTPUT_DIR,
    DTB_COMPONENTS,
    AIRCRAFT_SPEED_KMH,
)
from core.event_bus import EventBus, Event
from core.simulation_clock import SimulationClock
from core.lvc_architecture import LVCArchitecture, haversine
from models.entity import AircraftEntity, MissileEntity, SensorEntity, BattlefieldEntity
from models.track import TrackManager, Track
from services.spear_replay import SpearReplay

# P0 upgrades: learning manager + realtime push
try:
    from learning import LearningManager

    _learning_available = True
except ImportError:
    _learning_available = False

try:
    from realtime import RealtimeServer

    _realtime_available = True
except ImportError:
    _realtime_available = False

# Deep RL: DQN agent for ASDA decision-making (stable_baselines3 + PyTorch)
try:
    from deep_rl.dqn_agent import DQNAgent
    import numpy as np

    _dqn_available = True
except ImportError:
    _dqn_available = False
    DQNAgent = None

# P1-2: Platform components
try:
    from dt_platform import PluginManager, RestGateway, DTRegistry

    _platform_available = True
except ImportError:
    _platform_available = False

# P2-3: LVC Live real-world data adapters (ADS-B / AIS / Weather)
try:
    from live_data import LiveAdapterManager

    _live_data_available = True
except ImportError:
    _live_data_available = False


class PMTECEngine:
    """Core PMTEC simulation engine - drives the ASDA loop."""

    def __init__(self):
        self.clock = SimulationClock(SIM_TICK_SECONDS)
        self.event_bus = EventBus()
        self.lvc = LVCArchitecture()
        self.track_mgr = TrackManager()
        self.spear = SpearReplay()
        self.asda_phase_idx = 0
        self.asda_cycle_count = 0
        self.scenario_name = ""
        self.duration = SIM_DURATION_SECONDS
        self._running = False
        self._thread: Optional[threading.Thread] = None
        self._stop_flag = threading.Event()
        self._bases: list[dict] = []
        self._entities: list[BattlefieldEntity] = []
        self._sensors: list[SensorEntity] = []
        self._missiles: list[MissileEntity] = []
        self._app_store: dict[str, dict] = {}
        self._components: dict[str, dict] = {}
        self._start_time: float = 0
        self._init_app_store()
        self._init_components()
        random.seed(SIM_RANDOM_SEED)

        # P0-3: Learning manager for ASDA Adapt
        self.learning = None
        if _learning_available:
            self.learning = LearningManager()
            print(
                "[Engine] Learning manager initialized (UCB1 + Q-learning + Sensor opt)"
            )

        # P0-1: Realtime WebSocket push server
        self.realtime = None
        if _realtime_available:
            self.realtime = RealtimeServer()

        # Deep RL: DQN agent for ASDA decisions
        self.dqn = None
        if _dqn_available:
            self.dqn = DQNAgent()
            loaded = self.dqn.load()
            if loaded:
                print("[Engine] DQN model loaded (deep RL active)")
            else:
                print("[Engine] DQN not trained yet (run train_dqn.py to enable)")

        # P1-2: Platform components (plugin manager, REST gateway, DT registry)
        self.plugin_manager = None
        self.rest_gateway = None
        self.dt_registry = None
        if _platform_available:
            self.plugin_manager = PluginManager()
            self.plugin_manager.load_all(self)
            self.dt_registry = DTRegistry()
            self.dt_registry.register(
                {
                    "name": "PMTEC-Pacific-Main",
                    "scenario": "PMTEC-Pacific",
                    "tags": ["primary", "indopacom"],
                }
            )
            self.dt_registry.attach_engine(
                self.dt_registry.get_default().instance_id, self
            )
            self.rest_gateway = RestGateway(
                engine=self,
                plugin_manager=self.plugin_manager,
                dt_registry=self.dt_registry,
            )
            print(
                "[Engine] Platform initialized: PluginManager + RestGateway + DTRegistry"
            )

        # Track intercept outcomes for learning
        self._intercept_results: list[dict] = []
        self._dispersal_actions: list[dict] = []

        # P2-3: LVC Live real-world data adapters
        self.live_data = None
        self._live_injection_stats: dict = {}
        if _live_data_available:
            self.live_data = LiveAdapterManager(use_real_api=False)
            print("[Engine] LVC Live data adapters initialized (ADS-B + AIS + Weather)")

    def _init_app_store(self):
        """Initialize the DTB Application Store with capability modules."""
        apps = [
            (
                "app-f35-strike",
                "F-35A Strike Package",
                "v2.1",
                "strike",
                "Stealth strike mission planning with sensor fusion and threat avoidance",
            ),
            (
                "app-iamd-defense",
                "IAMD Integrated Air Defense",
                "v3.0",
                "defense",
                "Multi-layer air defense: PAC-3, THAAD, Aegis coordination via C2BMC",
            ),
            (
                "app-isr-collection",
                "ISR Sensor Collection",
                "v1.8",
                "isr",
                "Multi-INT sensor tasking: SIGINT, GEOINT, MASINT fusion and tipper-cueing",
            ),
            (
                "app-ace-dispersal",
                "ACE Agile Combat Employment",
                "v2.5",
                "logistics",
                "Distributed aircraft dispersal algorithm with risk-weighted basing",
            ),
            (
                "app-spear-replay",
                "SPEAR Replay Analysis",
                "v1.2",
                "analysis",
                "Post-action review with event timeline reconstruction and ASDA metrics",
            ),
            (
                "app-jad-ai",
                "JAD-AI Joint All-Domain AI",
                "v0.9-beta",
                "decision",
                "AI-assisted decision support across all domains with human-on-the-loop",
            ),
        ]
        for app_id, name, ver, cat, desc in apps:
            self._app_store[app_id] = {
                "app_id": app_id,
                "name": name,
                "version": ver,
                "category": cat,
                "description": desc,
            }

    def _init_components(self):
        """Initialize Plug-and-Play registered components."""
        components = [
            (
                "comp-sim-core",
                "simulation_engine",
                "pmtec://sim:50051",
                {"framework": "PMTEC", "lvc": "all"},
            ),
            (
                "comp-track-fusion",
                "track_manager",
                "pmtec//track:50051",
                {"fusion": "kinematic", "sources": "multi"},
            ),
            (
                "comm-grpc-bridge",
                "grpc_interface",
                "pmtec//grpc:50051",
                {"proto": "dtb_model.proto", "services": "4"},
            ),
            (
                "comp-asda-loop",
                "decision_engine",
                "pmtec//asda:50051",
                {"cycle_s": str(ASDA_CYCLE_SECONDS), "phases": "4"},
            ),
        ]
        for comp_id, comp_type, endpoint, meta in components:
            self._components[comp_id] = {
                "component_id": comp_id,
                "component_type": comp_type,
                "endpoint": endpoint,
                "metadata": meta,
            }

    def load_bases(self, geojson_path: str = None):
        """Load base data from GeoJSON (Level 1 data)."""
        import re

        path = geojson_path or BASES_GEOJSON
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        self._bases = []
        # Match aircraft designations: F-35A, KC-135, B-1B, CV-22, F/A-18, etc.
        ac_pattern = re.compile(r"\b([A-Z]{1,3}[-/]\d+[A-Z]?)\b")
        for feat in data.get("features", []):
            props = feat.get("properties", {})
            coords = feat.get("geometry", {}).get("coordinates", [0, 0])
            # Parse aircraft string to list of types
            aircraft_str = props.get("aircraft", "")
            found = ac_pattern.findall(aircraft_str) if aircraft_str else []
            # Normalize common types: F-35 -> F-35A, F-16 -> F-16C, F-22 -> F-22A
            normalize = {
                "F-35": "F-35A",
                "F-35B": "F-35A",
                "F-16": "F-16C",
                "F-22": "F-22A",
                "F-15": "F-15C",
            }
            aircraft_types = list(set(normalize.get(t, t) for t in found))
            base = {
                "id": props.get("id", props.get("name", "")),
                "name": props.get("name", ""),
                "lat": coords[1] if len(coords) >= 2 else props.get("lat", 0),
                "lon": coords[0] if len(coords) >= 2 else props.get("lon", 0),
                "region": props.get("region", ""),
                "military_branch": props.get("branch", ""),
                "is_ace_hub": props.get("ace_hub", False),
                "aircraft_types": aircraft_types,
                "sensor_types": ["AN/TPS-80"],
            }
            self._bases.append(base)
        return len(self._bases)

    def setup_scenario(self, scenario_name: str = "PMTEC-Pacific"):
        """Initialize the battlefield with entities from base data."""
        self.scenario_name = scenario_name
        if not self._bases:
            self.load_bases()

        # Create Live layer: sensors at each base
        for base in self._bases:
            for sensor_type in base.get("sensor_types", ["AN/TPS-80"]):
                sensor = SensorEntity(
                    sensor_type=sensor_type,
                    lat=base["lat"],
                    lon=base["lon"],
                    base_id=base["id"],
                    detection_range_km=400,
                )
                self.lvc.live.add_entity(sensor)
                self._sensors.append(sensor)

        # Create Virtual layer: aircraft at ACE hubs
        ace_hubs = [b for b in self._bases if b.get("is_ace_hub")]
        for base in ace_hubs:
            for ac_type in base.get("aircraft_types", ["F-35A"]):
                count = 4 if ac_type.startswith("F-3") else 2
                for i in range(count):
                    ac = AircraftEntity(
                        ac_type=ac_type,
                        base_id=base["id"],
                        lat=base["lat"] + random.uniform(-0.05, 0.05),
                        lon=base["lon"] + random.uniform(-0.05, 0.05),
                        callsign=f"{base['id'][:4].upper()}{ac_type[:3]}{i + 1:02d}",
                    )
                    ac.assign_mission("patrol")
                    self.lvc.virtual.add_entity(ac)
                    self._entities.append(ac)

        # Create Constructive layer: high-level command entities
        cmd_entity = BattlefieldEntity(
            id="CMD-INDOPACOM",
            entity_type="command",
            subtype="JOC",
            lat=21.35,
            lon=-157.96,  # INDOPACOM HQ Honolulu
            affiliation="friendly",
            status="active",
        )
        self.lvc.constructive.add_entity(cmd_entity)
        self._entities.append(cmd_entity)

        # Record initial state
        self.spear.record_snapshot(self.get_state_dict())

    def start_simulation(self, scenario_name: str, duration: int, seed: int):
        """Start the PMTEC simulation."""
        if self._running:
            return False, "Simulation already running"

        random.seed(seed)
        self.duration = duration or SIM_DURATION_SECONDS
        self.setup_scenario(scenario_name)

        self._running = True
        self._stop_flag.clear()
        self.clock.start()
        self._start_time = time.time()

        # Start simulation thread
        self._thread = threading.Thread(target=self._run_loop, daemon=True)
        self._thread.start()

        self._emit_event(
            "sim_start",
            "system",
            "PMTEC simulation started",
            {
                "scenario": scenario_name,
                "duration": duration,
                "seed": seed,
                "asda_phase": "Act",
                "lvc_layer": "Constructive",
            },
        )
        return True, f"Simulation started: {scenario_name}"

    def stop_simulation(self):
        """Stop the simulation."""
        if not self._running:
            return False, "Simulation not running"
        self._stop_flag.set()
        self._running = False
        self.clock.stop()
        if self._thread:
            self._thread.join(timeout=5)
        self._emit_event(
            "sim_stop",
            "system",
            "PMTEC simulation stopped",
            {
                "total_cycles": self.clock.current.cycle_count,
                "asda_phase": "Adapt",
                "lvc_layer": "Constructive",
            },
        )
        return True, "Simulation stopped"

    def _run_loop(self):
        """Main simulation loop - executes ASDA cycle."""
        tick_count = 0
        while (
            not self._stop_flag.is_set()
            and self.clock.current.sim_seconds < self.duration
        ):
            self.clock.tick()
            tick_count += 1

            # ASDA cycle every ASDA_CYCLE_SECONDS
            if tick_count % int(ASDA_CYCLE_SECONDS / SIM_TICK_SECONDS) == 0:
                self._execute_asda_cycle()

            # Update entities every tick
            self._update_entities(SIM_TICK_SECONDS)

            # Update tracks every 5 ticks
            if tick_count % 5 == 0:
                self._update_tracks()

            # Record snapshot every 10 ticks
            if tick_count % 10 == 0:
                self.spear.record_snapshot(self.get_state_dict())

            # Record metrics
            self.spear.record_metric("active_entities", len(self._active_entities()))
            self.spear.record_metric("active_tracks", len(self.track_mgr.active_tracks))
            self.spear.record_metric("network_vuln", self._calc_network_vulnerability())

            # Sleep for real-time pacing
            time.sleep(0.01)  # fast simulation

        self._running = False

    def _execute_asda_cycle(self):
        """Execute one ASDA (Act-Sense-Decide-Adapt) cycle."""
        phase = ASDA_PHASES[self.asda_phase_idx]
        self.asda_phase_idx = (self.asda_phase_idx + 1) % len(ASDA_PHASES)
        self.asda_cycle_count += 1

        if phase == "Act":
            self._asda_act()
            # P1-2: Plugin hook - inject EW/cyber threats
            if self.plugin_manager:
                self.plugin_manager.call_hook("pre_asda_act", self)
        elif phase == "Sense":
            self._asda_sense()
            # P1-2: Plugin hook - apply EW effects to sensors
            if self.plugin_manager:
                self.plugin_manager.call_hook("post_asda_sense", self)
        elif phase == "Decide":
            self._asda_decide()
        elif phase == "Adapt":
            self._asda_adapt()
            # P1-2: Plugin hook - apply cyber effects, collect stats
            if self.plugin_manager:
                self.plugin_manager.call_hook("post_asda_adapt", self)

        self._emit_event(
            "asda_cycle",
            "ASDA-Engine",
            f"ASDA cycle {self.asda_cycle_count}: {phase} phase",
            {
                "cycle": self.asda_cycle_count,
                "phase": phase,
                "lvc_layer": "Constructive",
            },
        )

    def _asda_act(self):
        """Act phase: execute current orders, missile launches, deployments."""
        # Random missile launch from hostile forces
        if random.random() < 0.30 and self._bases:
            target_base = random.choice(self._bases)
            launch_lat = target_base["lat"] + random.uniform(
                -2, -5
            )  # 220-550km from target
            launch_lon = target_base["lon"] + random.uniform(-5, -2)
            missile_type = random.choice(["DF-21D", "DF-26", "DF-17"])
            missile = MissileEntity(
                missile_type,
                launch_lat,
                launch_lon,
                target_base["lat"],
                target_base["lon"],
            )
            self.lvc.virtual.add_entity(missile)
            self._missiles.append(missile)
            self._entities.append(missile)
            self._emit_event(
                "missile_launch",
                "hostile",
                f"{missile_type} launched toward {target_base['name']}",
                {
                    "missile_type": missile_type,
                    "target": target_base["id"],
                    "lvc_layer": "Virtual",
                },
            )

        # ACE dispersal: move some aircraft to alternate bases
        # P0-3: Use Q-learning to select dispersal target
        if random.random() < 0.2 and len(self._bases) > 1:
            aircraft = [
                e
                for e in self._entities
                if isinstance(e, AircraftEntity)
                and e.status == "active"
                and e.mission == "patrol"
            ]
            if aircraft:
                ac = random.choice(aircraft)
                alt_bases = [b for b in self._bases if b["id"] != ac.base_id]
                # P0-3: Q-learning selects dispersal target
                if self.learning and alt_bases:
                    threat_dir = "west"  # simplified
                    target_id = self.learning.select_dispersal_target(
                        ac.base_id, [b["id"] for b in alt_bases], threat_dir
                    )
                    alt_base = next(
                        (b for b in alt_bases if b["id"] == target_id), alt_bases[0]
                    )
                else:
                    alt_base = random.choice(alt_bases)

                ac.assign_mission("transfer", alt_base["lat"], alt_base["lon"])
                self._dispersal_actions.append(
                    {
                        "from_base": ac.base_id,
                        "target_base": alt_base["id"],
                        "threat_dir": "west",
                        "ac_type": ac.subtype,
                    }
                )
                self._emit_event(
                    "transfer",
                    ac.id,
                    f"{ac.subtype} transferring from {ac.base_id} to {alt_base['id']}",
                    {
                        "from": ac.base_id,
                        "to": alt_base["id"],
                        "ac_type": ac.subtype,
                        "lvc_layer": "Virtual",
                    },
                )

    def _asda_sense(self):
        """Sense phase: run all sensors, collect tracks + inject live data."""
        # P2-3: Inject real-world sensor data (ADS-B/AIS/Weather) into LVC Live
        if self.live_data:
            self._live_injection_stats = self.live_data.inject_into_lvc(self.lvc)
            wx_impact = self.live_data.get_weather_impact()
            self._emit_event(
                "live_data_inject",
                "LVC-Live",
                f"Live data injected: {self._live_injection_stats.get('total_injected', 0)} entities",
                {
                    **self._live_injection_stats,
                    "wx_detection_factor": wx_impact.get("detection_range_factor", 1.0),
                    "lvc_layer": "Live",
                },
            )

        all_entities = self.lvc.all_entities()
        for sensor in self._sensors:
            if sensor.status == "active":
                detections = sensor.scan(all_entities)
                for det in detections:
                    self.track_mgr.add_observation(
                        lat=det["lat"],
                        lon=det["lon"],
                        alt_m=det["alt_m"],
                        heading=det["heading_deg"],
                        speed=det["speed_kmh"],
                        confidence=det["confidence"],
                        classification=det["classification"],
                        source=det["source"],
                    )
                    self._emit_event(
                        "detect",
                        sensor.id,
                        f"Sensor detected track at ({det['lat']:.2f}, {det['lon']:.2f})",
                        {
                            "confidence": det["confidence"],
                            "classification": det["classification"],
                            "lvc_layer": "Live",
                        },
                    )

    def _build_dqn_observation(self) -> "np.ndarray":
        """Build 94-dim observation vector for DQN from current engine state."""
        import numpy as np

        NUM_BASES = 22
        BASE_FEATS = 4
        GLOBAL_FEATS = 6
        obs = np.zeros(NUM_BASES * BASE_FEATS + GLOBAL_FEATS, dtype=np.float32)
        for i, b in enumerate(self._bases[:NUM_BASES]):
            ac = sum(
                1
                for e in self._entities
                if isinstance(e, AircraftEntity)
                and e.base_id == b["id"]
                and e.status == "active"
            )
            dst = sum(
                1
                for e in self._entities
                if isinstance(e, AircraftEntity)
                and e.base_id == b["id"]
                and e.status == "destroyed"
            )
            sen = (
                1.0
                if any(
                    s.base_id == b["id"] and s.status == "active" for s in self._sensors
                )
                else 0.0
            )
            threats = sum(
                1 for m in self._missiles if m.status == "active" and m.lat is not None
            )
            obs[i * BASE_FEATS + 0] = min(ac / 10.0, 1.0)
            obs[i * BASE_FEATS + 1] = min(dst / 10.0, 1.0)
            obs[i * BASE_FEATS + 2] = sen
            obs[i * BASE_FEATS + 3] = min(threats / 5.0, 1.0)
        off = NUM_BASES * BASE_FEATS
        active_msl = sum(1 for m in self._missiles if m.status == "active")
        n_tracks = len(self.track_mgr.fuse())
        vuln = self._calc_network_vulnerability()
        ir = 0.0
        if self._intercept_results:
            ir = len([r for r in self._intercept_results if r.get("strategy")]) / max(
                len(self._intercept_results), 1
            )
        dr = len(self._dispersal_actions) / max(len(self._entities), 1)
        obs[off + 0] = min(active_msl / 20.0, 1.0)
        obs[off + 1] = min(n_tracks / 20.0, 1.0)
        obs[off + 2] = min(self.asda_cycle_count / 30.0, 1.0)
        obs[off + 3] = vuln
        obs[off + 4] = ir
        obs[off + 5] = min(dr, 1.0)
        return obs

    def _asda_decide(self):
        """Decide phase: evaluate threats, decide countermeasures.
        Deep RL (DQN) overrides UCB1 when a trained model is available."""
        tracks = self.track_mgr.fuse()
        hostile_tracks = [
            t
            for t in tracks.values()
            if t.classification in ("missile", "aircraft") and t.confidence > 0.5
        ]

        # Deep RL: DQN selects action (0-5) from observation
        dqn_action = None
        if self.dqn and self.dqn.is_trained():
            obs = self._build_dqn_observation()
            dqn_action = self.dqn.predict(obs, deterministic=True)
            # Decode: action // 2 = intercept strategy (0=direct,1=predictive,2=saturation)
            # action % 2 = should_disperse (0=no, 1=yes)
            strategy_map = {0: "direct", 1: "predictive", 2: "saturation"}
            intercept_strategy = strategy_map.get(dqn_action // 2, "direct")
            should_disperse = dqn_action % 2 == 1
            self._emit_event(
                "dqn_decision",
                "DQN-Agent",
                f"Deep RL action={dqn_action}: {intercept_strategy} intercept + dispersal={should_disperse}",
                {
                    "dqn_action": dqn_action,
                    "intercept_strategy": intercept_strategy,
                    "should_disperse": should_disperse,
                    "asda_phase": "Decide",
                    "lvc_layer": "Constructive",
                },
            )
            # Execute DQN-directed dispersal
            if should_disperse and self._bases and self._entities:
                self._do_dqn_dispersal()
        elif self.learning:
            # Fallback: UCB1
            intercept_strategy = self.learning.select_intercept_strategy()
        else:
            intercept_strategy = "direct"

        for track in hostile_tracks:
            # Decide: intercept or evade
            if track.classification == "missile":
                self._emit_event(
                    "intercept_decision",
                    "ASDA-Engine",
                    f"Decide: {intercept_strategy} intercept hostile track {track.track_id}",
                    {
                        "track_id": track.track_id,
                        "confidence": track.confidence,
                        "asda_phase": "Decide",
                        "lvc_layer": "Constructive",
                        "intercept_strategy": intercept_strategy,
                    },
                )
                # Record intercept attempt for learning
                self._intercept_results.append(
                    {
                        "strategy": intercept_strategy,
                        "track_id": track.track_id,
                        "cycle": self.asda_cycle_count,
                    }
                )
            else:
                self._emit_event(
                    "evade_decision",
                    "ASDA-Engine",
                    f"Decide: evade hostile aircraft {track.track_id}",
                    {
                        "track_id": track.track_id,
                        "asda_phase": "Decide",
                        "lvc_layer": "Constructive",
                    },
                )

    def _do_dqn_dispersal(self):
        """Execute DQN-directed dispersal: move 15% of patrol aircraft to safest alternate base."""
        patrol_ac = [
            e
            for e in self._entities
            if isinstance(e, AircraftEntity)
            and e.status == "active"
            and e.mission == "patrol"
        ]
        n_transfer = max(1, int(len(patrol_ac) * 0.15))
        if n_transfer == 0 or len(self._bases) < 2:
            return

        # Pick aircraft from most threatened bases
        def base_threats(bid):
            return sum(
                1 for m in self._missiles if m.status == "active" and m.lat is not None
            )

        patrol_ac.sort(key=lambda a: base_threats(a.base_id), reverse=True)
        for ac in patrol_ac[:n_transfer]:
            src = ac.base_id
            candidates = [b for b in self._bases if b["id"] != src]

            # Safest = fewest threats targeting it + most aircraft already there
            def safety(b):
                threats = sum(1 for m in self._missiles if m.status == "active")
                ac_count = sum(
                    1
                    for e in self._entities
                    if isinstance(e, AircraftEntity)
                    and e.base_id == b["id"]
                    and e.status == "active"
                )
                return threats - ac_count

            safest = min(candidates, key=safety)
            ac.assign_mission("transfer", safest["lat"], safest["lon"])
            self._dispersal_actions.append(
                {
                    "from_base": src,
                    "target_base": safest["id"],
                    "threat_dir": "dqn",
                    "ac_type": ac.subtype,
                }
            )
            self._emit_event(
                "dqn_dispersal",
                "DQN-Agent",
                f"Deep RL dispersal: {ac.subtype} {src} -> {safest['id']}",
                {
                    "from": src,
                    "to": safest["id"],
                    "ac_type": ac.subtype,
                    "lvc_layer": "Virtual",
                },
            )

    def _asda_adapt(self):
        """Adapt phase: apply decisions, update deployments, learn.
        P0-3: Records intercept/dispersal outcomes to learning manager,
        updates strategy parameters for next cycle."""
        # Check missile impacts and record intercept outcomes
        intercept_success_count = 0
        intercept_attempt_count = len(self._intercept_results)

        for missile in self._missiles:
            if missile.status == "destroyed" and missile.impact_time > 0:
                # Assess damage at impact site
                impact_base = min(
                    self._bases,
                    key=lambda b: haversine(
                        b["lat"], b["lon"], missile.lat, missile.lon
                    ),
                )
                dist = haversine(
                    impact_base["lat"], impact_base["lon"], missile.lat, missile.lon
                )
                if dist < 5.0:  # hit the base
                    # Monte Carlo damage assessment (simplified)
                    hit_prob = min(0.8, 1.0 - (missile.cep / 1000) / max(dist, 0.1))
                    if random.random() < hit_prob:
                        # Damage nearby aircraft
                        nearby_ac = [
                            e
                            for e in self._entities
                            if isinstance(e, AircraftEntity)
                            and e.distance_to(missile.lat, missile.lon) < 5
                            and e.status == "active"
                        ]
                        for ac in nearby_ac[:2]:  # max 2 damaged
                            ac.status = "destroyed"
                            self._emit_event(
                                "damage",
                                missile.id,
                                f"{ac.subtype} {ac.id} destroyed at {impact_base['name']}",
                                {
                                    "base": impact_base["id"],
                                    "ac_type": ac.subtype,
                                    "missile_type": missile.subtype,
                                    "lvc_layer": "Virtual",
                                },
                            )
                missile.impact_time = 0  # mark as processed

        # P0-3: Record intercept outcomes for UCB1 learning
        # An intercept is "successful" if the missile was destroyed before impact
        # or if no damage occurred at the target base
        for result in self._intercept_results:
            track_id = result["track_id"]
            strategy = result["strategy"]
            # Find the corresponding missile
            missile = next(
                (
                    m
                    for m in self._missiles
                    if m.id == track_id or m.status == "destroyed"
                ),
                None,
            )
            if missile:
                # Missile destroyed before reaching target = successful intercept
                # Check if missile was destroyed before impact (impact_time == 0 and not processed)
                success = missile.status == "destroyed"
            else:
                success = True  # No missile found = threat neutralized

            if self.learning:
                self.learning.record_intercept_result(strategy, success)
            if success:
                intercept_success_count += 1

        self._intercept_results.clear()

        # P0-3: Record dispersal outcomes for Q-learning
        for action in self._dispersal_actions:
            if self.learning:
                # Calculate loss rate: fraction of aircraft at target base destroyed
                target_base_id = action.get("target_base", "")
                ac_at_target = [
                    e
                    for e in self._entities
                    if isinstance(e, AircraftEntity) and e.base_id == target_base_id
                ]
                destroyed_at_target = [
                    e for e in ac_at_target if e.status == "destroyed"
                ]
                loss_rate = len(destroyed_at_target) / max(len(ac_at_target), 1)

                self.learning.record_dispersal_result(
                    current_base=action.get("from_base", ""),
                    target_base=target_base_id,
                    threat_dir=action.get("threat_dir", "unknown"),
                    loss_rate=loss_rate,
                    next_base=target_base_id,
                    next_available=[b["id"] for b in self._bases],
                )

        self._dispersal_actions.clear()

        # P0-3: Record sensor coverage
        if self.learning and self._sensors and self._bases:
            base_coverage = {}
            for base in self._bases:
                sensors_at_base = [s for s in self._sensors if s.base_id == base["id"]]
                if sensors_at_base:
                    threats_near = [
                        e
                        for e in self._entities
                        if e.affiliation == "hostile" and e.status == "active"
                    ]
                    if threats_near:
                        detected = 0
                        for s in sensors_at_base:
                            for threat in threats_near:
                                if (
                                    s.distance_to(threat.lat, threat.lon)
                                    <= s.detection_range_km
                                ):
                                    detected += 1
                                    break
                        base_coverage[base["id"]] = detected / max(len(threats_near), 1)
                    else:
                        base_coverage[base["id"]] = 1.0
                else:
                    base_coverage[base["id"]] = 0.0

            self.learning.record_sensor_coverage(base_coverage)

        # P0-3: End learning cycle
        if self.learning:
            cycle_data = {
                "cycle": self.asda_cycle_count,
                "intercept_attempts": intercept_attempt_count,
                "intercept_successes": intercept_success_count,
                "active_entities": len(self._active_entities()),
                "sim_seconds": self.clock.current.sim_seconds,
            }
            self.learning.end_cycle(cycle_data)

        # Recover: transfer aircraft back from alternate bases
        landed = [
            e
            for e in self._entities
            if isinstance(e, AircraftEntity) and e.status == "landed"
        ]
        for ac in landed:
            if random.random() < 0.3:
                home_base = next(
                    (b for b in self._bases if b["id"] == ac.base_id), None
                )
                if home_base:
                    ac.status = "active"
                    ac.assign_mission("transfer", home_base["lat"], home_base["lon"])
                    self._emit_event(
                        "recover",
                        ac.id,
                        f"{ac.subtype} recovering to {ac.base_id}",
                        {
                            "ac_type": ac.subtype,
                            "to": ac.base_id,
                            "lvc_layer": "Virtual",
                        },
                    )

        # P0-1: Push real-time update after Adapt phase
        if self.realtime:
            state = self.get_state_dict()
            recent_events = self.spear.events[-20:]
            self.realtime.push_state(state, recent_events)

    def _update_entities(self, dt: float):
        """Update all entity positions."""
        from models.entity import EWThreatEntity, CyberThreatEntity

        for entity in self._entities:
            if isinstance(entity, AircraftEntity):
                entity.update(dt)
            elif isinstance(entity, MissileEntity):
                entity.update(dt)
            elif isinstance(entity, (EWThreatEntity, CyberThreatEntity)):
                entity.update(dt)

        # Clean up destroyed missiles from all lists
        active_missiles = [m for m in self._missiles if m.status == "active"]
        destroyed = [m for m in self._missiles if m.status != "active"]
        for m in destroyed:
            self.lvc.virtual.remove_entity(m.id)
        self._missiles = active_missiles
        # Also clean up destroyed/neutralized entities from entities list
        self._entities = [
            e
            for e in self._entities
            if e.status not in ("destroyed", "neutralized")
            or isinstance(e, AircraftEntity)
        ]

    def _update_tracks(self):
        """Fuse and update track picture."""
        self.track_mgr.fuse()

    def _calc_network_vulnerability(self) -> float:
        """Calculate network vulnerability score (0=secure, 1=critical)."""
        active = len(self._active_entities())
        destroyed = len([e for e in self._entities if e.status == "destroyed"])
        if active + destroyed == 0:
            return 0.0
        return min(1.0, destroyed / max(active + destroyed, 1) * 2)

    def _active_entities(self) -> list:
        return [e for e in self._entities if e.status == "active"]

    def _emit_event(
        self, event_type: str, source: str, description: str, data: dict = None
    ):
        """Emit and record a simulation event."""
        evt = Event(
            event_type=event_type,
            timestamp=time.time(),
            source=source,
            data=data or {},
        )
        self.event_bus.publish(evt)
        evt_dict = evt.to_dict()
        evt_dict["description"] = description
        self.spear.record_event(evt_dict)

    def get_state_dict(self) -> dict:
        """Get current system state as dictionary."""
        return {
            "sim_time": str(self.clock.current),
            "sim_seconds": self.clock.current.sim_seconds,
            "total_entities": len(self._entities),
            "active_tracks": len(self.track_mgr.active_tracks),
            "asda_cycle": self.asda_cycle_count,
            "asda_phase": ASDA_PHASES[(self.asda_phase_idx - 1) % 4]
            if self.asda_cycle_count > 0
            else "idle",
            "network_vulnerability": round(self._calc_network_vulnerability(), 3),
            "entities": [e.to_dict() for e in self._entities if e.status == "active"],
            "tracks": [t.to_dict() for t in self.track_mgr.active_tracks],
            "live_data_stats": self._live_injection_stats if self.live_data else {},
            "lvc_live_entities": self.lvc.live.entity_count if self.lvc else 0,
        }

    # ---- gRPC service implementations ----

    def get_state_proto(self, at_time: int = 0) -> pb.SystemState:
        """Convert state to protobuf message."""
        state = self.get_state_dict()
        msg = pb.SystemState(
            sim_time=int(state["sim_seconds"]),
            total_entities=state["total_entities"],
            active_tracks=state["active_tracks"],
            asda_cycle=state["asda_cycle"],
            asda_phase=state["asda_phase"],
            network_vulnerability=state["network_vulnerability"],
            strike_capability=len(
                [
                    e
                    for e in self._entities
                    if isinstance(e, AircraftEntity) and e.status == "active"
                ]
            ),
        )
        for e_dict in state["entities"]:
            msg.entities.add(
                id=e_dict["id"],
                type=e_dict["type"],
                subtype=e_dict["subtype"],
                lat=e_dict["lat"],
                lon=e_dict["lon"],
                alt_m=e_dict["alt_m"],
                heading_deg=e_dict["heading"],
                speed_kmh=e_dict["speed_kmh"],
                affiliation=e_dict["affiliation"],
                base_id=e_dict["base_id"],
                status=e_dict["status"],
            )
        for t_dict in state["tracks"]:
            msg.tracks.add(
                track_id=t_dict["track_id"],
                lat=t_dict["lat"],
                lon=t_dict["lon"],
                alt_m=t_dict["alt_m"],
                heading_deg=t_dict["heading"],
                speed_kmh=t_dict["speed_kmh"],
                confidence=t_dict["confidence"],
                classification=t_dict["classification"],
            )
        # Recent events (last 10)
        for evt in self.spear.events[-10:]:
            sim_evt = msg.recent_events.add(
                event_id=evt.get("event_id", ""),
                event_type=evt.get("event_type", ""),
                timestamp=int(evt.get("timestamp", 0)),
                actor=evt.get("source", ""),
                description=evt.get("description", ""),
            )
            for k, v in evt.get("data", {}).items():
                if isinstance(v, (str, int, float)):
                    sim_evt.params[str(k)] = str(v)
        return msg


class WarEngineServicer(pb_grpc.WarEngineServicer):
    """DTB WarEngine service - simulation control."""

    def __init__(self, engine: PMTECEngine):
        self.engine = engine

    def StartSimulation(self, request, context):
        success, msg = self.engine.start_simulation(
            request.scenario_name, request.duration_seconds, request.seed
        )
        return pb.Ack(success=success, message=msg)

    def StopSimulation(self, request, context):
        success, msg = self.engine.stop_simulation()
        return pb.Ack(success=success, message=msg)

    def GetState(self, request, context):
        return self.engine.get_state_proto(request.at_time)

    def InjectEvent(self, request, context):
        self.engine._emit_event(
            request.event_type, request.actor, request.description, dict(request.params)
        )
        return pb.Ack(success=True, message=f"Event {request.event_id} injected")

    def GetSpearReport(self, request, context):
        report = self.engine.spear.generate_report(request.start_time, request.end_time)
        msg = pb.SpearReport(
            total_duration=int(report["total_duration_s"]),
            total_events=int(report["total_events"]),
            total_tracks=int(len(self.engine.track_mgr.tracks)),
            summary=report["summary"],
        )
        for evt in report.get("timeline", []):
            msg.timeline.add(
                event_id=str(evt.get("event_id", "")),
                event_type=str(evt.get("event_type", "")),
                timestamp=int(float(evt.get("timestamp", 0))),
                actor=str(evt.get("source", "")),
                description=str(evt.get("description", "")),
            )
        return msg

    # ---- P2: EW/Cyber threat RPCs ----

    def GetEWThreats(self, request, context):
        """Get electronic warfare threats."""
        from models.entity import EWThreatEntity

        msg = pb.EWThreatList()
        for entity in self.engine._entities:
            if not isinstance(entity, EWThreatEntity):
                continue
            if (
                request.target_base_id
                and entity.target_base_id != request.target_base_id
            ):
                continue
            if request.active_only and entity.status != "active":
                continue
            t = msg.threats.add(
                threat_id=entity.id,
                ew_type=entity.subtype,
                lat=entity.lat or 0.0,
                lon=entity.lon or 0.0,
                alt_m=entity.alt_m or 0.0,
                power_kw=entity.power_kw,
                jam_range_km=entity.jam_range_km,
                effectiveness=entity.effectiveness,
                target_base_id=getattr(entity, "target_base_id", ""),
                status=entity.status,
            )
            t.jammed_bands.extend(entity.jammed_bands)
        return msg

    def GetCyberThreats(self, request, context):
        """Get cyber threats."""
        from models.entity import CyberThreatEntity

        msg = pb.CyberThreatList()
        for entity in self.engine._entities:
            if not isinstance(entity, CyberThreatEntity):
                continue
            if (
                request.target_base_id
                and entity.target_base_id != request.target_base_id
            ):
                continue
            if request.detected_only and not entity.detected:
                continue
            msg.threats.add(
                threat_id=entity.id,
                attack_type=entity.subtype,
                target_base_id=entity.target_base_id or "",
                target_system=entity.target_system or "",
                phase=entity.phase,
                detection_difficulty=entity.detection_difficulty,
                impact_severity=entity.impact_severity,
                effectiveness=entity.effectiveness,
                detected=entity.detected,
                impact_score=entity.impact_score,
                status=entity.status,
            )
        return msg

    def GetThreatSummary(self, request, context):
        """Get summary of all active threats."""
        from models.entity import EWThreatEntity, CyberThreatEntity

        ew_active = sum(
            1
            for e in self.engine._entities
            if isinstance(e, EWThreatEntity) and e.status == "active"
        )
        cyber_active = sum(
            1
            for e in self.engine._entities
            if isinstance(e, CyberThreatEntity) and e.status == "active"
        )
        cyber_detected = sum(
            1
            for e in self.engine._entities
            if isinstance(e, CyberThreatEntity) and e.detected
        )
        kinetic_active = sum(1 for m in self.engine._missiles if m.status == "active")
        return pb.ThreatSummary(
            ew_active=ew_active,
            cyber_active=cyber_active,
            cyber_detected=cyber_detected,
            kinetic_active=kinetic_active,
        )


class BattleNetworkServicer(pb_grpc.BattleNetworkServicer):
    """DTB BattleNetwork service - track and entity management."""

    def __init__(self, engine: PMTECEngine):
        self.engine = engine

    def GetTrackFeed(self, request, context):
        """Stream track updates to subscribers."""
        last_count = 0
        while self.engine._running or context.is_active():
            tracks = self.engine.track_mgr.active_tracks
            if len(tracks) != last_count:
                update = pb.TrackUpdate(timestamp=int(time.time()))
                for t in tracks:
                    if (
                        request.min_lat <= t.lat <= request.max_lat
                        and request.min_lon <= t.lon <= request.max_lon
                    ):
                        if (
                            not request.classification_filter
                            or t.classification == request.classification_filter
                        ):
                            update.tracks.add(
                                track_id=t.track_id,
                                lat=t.lat,
                                lon=t.lon,
                                alt_m=t.alt_m,
                                heading_deg=t.heading_deg,
                                speed_kmh=t.speed_kmh,
                                confidence=t.confidence,
                                classification=t.classification,
                            )
                yield update
                last_count = len(tracks)
            time.sleep(1)

    def GetEntityStatus(self, request, context):
        """Get status of a specific entity."""
        for entity in self.engine._entities:
            if request.entity_id and entity.id != request.entity_id:
                continue
            if request.type_filter and entity.entity_type != request.type_filter:
                continue
            return pb.EntityStatus(
                entity=pb.Entity(
                    id=entity.id,
                    type=entity.entity_type,
                    subtype=entity.subtype,
                    lat=entity.lat,
                    lon=entity.lon,
                    alt_m=entity.alt_m,
                    heading_deg=entity.heading_deg,
                    speed_kmh=entity.speed_kmh,
                    affiliation=entity.affiliation,
                    base_id=entity.base_id,
                    status=entity.status,
                ),
                health="operational" if entity.status == "active" else entity.status,
                fuel_pct=getattr(entity, "fuel_pct", 1.0),
                ammo_count=getattr(entity, "ammo_count", 0),
            )
        return pb.EntityStatus()

    def GetNetworkState(self, request, context):
        """Get DTB BattleNetwork state."""
        active = len(self.engine._active_entities())
        total = len(self.engine._entities)
        degraded = total - active
        node_statuses = []
        for base in self.engine._bases[:10]:
            ac_count = len(
                [
                    e
                    for e in self.engine._entities
                    if isinstance(e, AircraftEntity) and e.base_id == base["id"]
                ]
            )
            node_statuses.append(
                f"{base['id']}: {ac_count} aircraft, {'active' if ac_count > 0 else 'empty'}"
            )
        return pb.NetworkState(
            total_nodes=len(self.engine._bases),
            active_nodes=len(
                [
                    b
                    for b in self.engine._bases
                    if any(
                        e.base_id == b["id"] and e.status == "active"
                        for e in self.engine._entities
                    )
                ]
            ),
            degraded_nodes=degraded,
            avg_latency_ms=round(random.uniform(15, 50), 1),
            node_status=node_statuses,
        )

    # ---- P2: LVC Live data RPCs ----

    def GetLiveFeed(self, request, context):
        """Stream live sensor data updates (AIS/ADS-B/weather)."""
        lvc = self.engine.lvc
        live_entities = lvc.live.entities if lvc else {}
        while self.engine._running or context.is_active():
            update = pb.LiveFeedUpdate(
                feed_source=request.feed_type or "all",
                timestamp=int(time.time()),
            )
            for entity in live_entities.values():
                if hasattr(entity, "lat") and entity.lat is not None:
                    if (
                        request.min_lat <= entity.lat <= request.max_lat
                        and request.min_lon <= entity.lon <= request.max_lon
                    ):
                        update.contacts.add(
                            sensor_id=getattr(entity, "id", ""),
                            sensor_type=getattr(entity, "entity_type", "sensor"),
                            lat=entity.lat,
                            lon=entity.lon,
                            alt_m=getattr(entity, "alt_m", 0.0),
                            heading_deg=getattr(entity, "heading_deg", 0.0),
                            speed_kmh=getattr(entity, "speed_kmh", 0.0),
                            callsign=getattr(entity, "callsign", ""),
                            affiliation=getattr(entity, "affiliation", "unknown"),
                            confidence=getattr(entity, "confidence", 0.8),
                            timestamp=int(time.time()),
                        )
            yield update
            time.sleep(2)

    def GetLVCStatus(self, request, context):
        """Get LVC (Live/Virtual/Constructive) layer status."""
        lvc = self.engine.lvc
        msg = pb.LVCStatus()
        for layer_name, layer in [
            ("Live", lvc.live),
            ("Virtual", lvc.virtual),
            ("Constructive", lvc.constructive),
        ]:
            count = len(layer.entities) if layer else 0
            msg.layers.add(
                layer_name=layer_name,
                enabled=True,
                entity_count=count,
                description=f"{layer_name} layer: {count} entities",
            )
        msg.total_entities = len(self.engine._entities)
        return msg


class ApplicationStoreServicer(pb_grpc.ApplicationStoreServicer):
    """DTB ApplicationStore service - capability management."""

    def __init__(self, engine: PMTECEngine):
        self.engine = engine

    def ListApps(self, request, context):
        msg = pb.AppList()
        for app_id, app in self.engine._app_store.items():
            if request.category and app["category"] != request.category:
                continue
            msg.apps.add(
                app_id=app["app_id"],
                name=app["name"],
                version=app["version"],
                category=app["category"],
                description=app["description"],
            )
        return msg

    def DeployApp(self, request, context):
        app = self.engine._app_store.get(request.app_id)
        if not app:
            return pb.DeployResult(
                success=False, message=f"App {request.app_id} not found"
            )
        deploy_id = f"DEP-{uuid.uuid4().hex[:8]}"
        self.engine._emit_event(
            "deploy",
            "ApplicationStore",
            f"App {app['name']} deployed to {request.target_base} x{request.count}",
            {
                "app_id": request.app_id,
                "base": request.target_base,
                "count": request.count,
                "lvc_layer": "Constructive",
            },
        )
        return pb.DeployResult(
            success=True,
            message=f"{app['name']} v{app['version']} deployed to {request.target_base}",
            deployment_id=deploy_id,
        )

    def QueryCapability(self, request, context):
        base = next((b for b in self.engine._bases if b["id"] == request.base_id), None)
        if not base:
            return pb.CapabilityReport(base_id=request.base_id)
        ac_list = [
            e
            for e in self.engine._entities
            if isinstance(e, AircraftEntity)
            and e.base_id == base["id"]
            and e.status == "active"
        ]
        strike = sum(
            1
            for a in ac_list
            if a.subtype.startswith("F-3") or a.subtype.startswith("F-15")
        )
        defense = len([s for s in self.engine._sensors if s.base_id == base["id"]])
        isr = len([a for a in ac_list if a.subtype in ("RC-135", "E-3")])
        logistics = len([a for a in ac_list if a.subtype.startswith("KC-")])
        return pb.CapabilityReport(
            base_id=base["id"],
            strike_capability=strike,
            defense_capability=defense,
            isr_capability=isr,
            logistics_capability=logistics,
        )

    # ---- P2: DQN inference RPCs ----

    def DQNInfer(self, request, context):
        """Run DQN inference on observation vector."""
        if not self.engine.dqn or not self.engine.dqn.is_trained():
            return pb.DQNInferenceResult(action=0, device="none")

        import numpy as np

        obs = np.array(request.observation, dtype=np.float32)
        action = self.engine.dqn.predict(obs, deterministic=request.deterministic)
        # Try to get Q-values if model is available
        q_values = []
        try:
            model = self.engine.dqn.model
            obs_tensor = model.policy.obs_to_tensor(obs)[0]
            q_vals = model.policy.q_net(obs_tensor)
            q_values = q_vals.detach().cpu().numpy().flatten().tolist()
        except Exception:
            pass

        device = "cpu"
        try:
            import torch

            device = str(model.policy.q_net.device)
        except Exception:
            pass

        return pb.DQNInferenceResult(
            action=int(action),
            q_values=q_values,
            device=device,
        )

    def GetDQNStatus(self, request, context):
        """Get DQN training status."""
        dqn = self.engine.dqn
        if not dqn:
            return pb.DQNTrainingStatus(is_trained=False)

        is_trained = dqn.is_trained()
        training_runs = getattr(dqn, "training_runs", 0)
        total_timesteps = getattr(dqn, "total_timesteps", 0)
        device = "cpu"
        policy_arch = ""
        obs_dim = 0
        action_space = 0
        try:
            model = dqn.model
            if model:
                import torch

                device = str(model.policy.q_net.device)
                policy_arch = str(model.policy.net_arch)
                obs_dim = model.observation_space.shape[0]
                action_space = model.action_space.n
        except Exception:
            pass

        return pb.DQNTrainingStatus(
            is_trained=is_trained,
            training_runs=training_runs,
            total_timesteps=total_timesteps,
            device=device,
            policy_arch=policy_arch,
            observation_dim=obs_dim,
            action_space_size=action_space,
        )


class PlugAndPlayServicer(pb_grpc.PlugAndPlayServicer):
    """DTB PlugAndPlay service - component registration and discovery."""

    def __init__(self, engine: PMTECEngine):
        self.engine = engine

    def RegisterComponent(self, request, context):
        comp_id = request.component_id or f"comp-{uuid.uuid4().hex[:8]}"
        self.engine._components[comp_id] = {
            "component_id": comp_id,
            "component_type": request.component_type,
            "endpoint": request.endpoint,
            "metadata": dict(request.metadata),
        }
        return pb.RegResult(
            success=True,
            component_id=comp_id,
            message=f"Component {comp_id} registered as {request.component_type}",
        )

    def DiscoverServices(self, request, context):
        msg = pb.ServiceList()
        for comp_id, comp in self.engine._components.items():
            if request.service_type and comp["component_type"] != request.service_type:
                continue
            msg.services.add(
                service_id=comp_id,
                service_type=comp["component_type"],
                endpoint=comp["endpoint"],
                healthy=True,
            )
        return msg

    def HealthCheck(self, request, context):
        uptime = time.time() - self.engine._start_time if self.engine._start_time else 0
        return pb.HealthStatus(
            healthy=True,
            version="PMTEC-v1.0",
            uptime_seconds=int(uptime),
            cpu_usage=round(random.uniform(10, 40), 1),
            active_connections=len(self.engine._components),
        )

    # ---- P2: Platform management RPCs ----

    def ListPlugins(self, request, context):
        """List registered plugins."""
        msg = pb.PluginList()
        pm = self.engine.plugin_manager
        if not pm:
            return msg
        # Use list_plugins() which returns list of dicts, fall back to _plugins
        plugin_list = pm.list_plugins() if hasattr(pm, "list_plugins") else []
        for pinfo in plugin_list:
            if (
                request.plugin_type
                and pinfo.get("plugin_type", "") != request.plugin_type
            ):
                continue
            if request.active_only and not pinfo.get("active", True):
                continue
            msg.plugins.add(
                plugin_id=pinfo.get("plugin_id", ""),
                name=pinfo.get("name", ""),
                version=pinfo.get("version", "1.0"),
                author=pinfo.get("author", "unknown"),
                description=pinfo.get("description", ""),
                plugin_type=pinfo.get("plugin_type", "generic"),
                active=pinfo.get("active", True),
                call_count=pinfo.get("call_count", 0),
                error_count=pinfo.get("error_count", 0),
            )
        return msg

    def ListDTInstances(self, request, context):
        """List registered Digital Twin instances."""
        msg = pb.DTInstanceList()
        dtr = self.engine.dt_registry
        if not dtr:
            return msg
        for inst in dtr.list_instances():
            dti = msg.instances.add(
                instance_id=inst.get("instance_id", ""),
                name=inst.get("name", ""),
                scenario=inst.get("scenario", ""),
                status=inst.get("status", ""),
                created_at=int(inst.get("created_at", 0)),
            )
            for k, v in inst.get("metadata", {}).items():
                dti.metadata[str(k)] = str(v)
            dti.tags.extend(inst.get("tags", []))
        return msg

    def RegisterDTInstance(self, request, context):
        """Register a new Digital Twin instance."""
        dtr = self.engine.dt_registry
        if not dtr:
            return pb.DTInstanceInfo()
        inst = dtr.register(
            {
                "name": request.name,
                "scenario": request.scenario,
                "tags": list(request.tags),
                "metadata": dict(request.metadata),
            }
        )
        return pb.DTInstanceInfo(
            instance_id=inst.get("instance_id", ""),
            name=inst.get("name", ""),
            scenario=inst.get("scenario", ""),
            status=inst.get("status", ""),
            created_at=int(inst.get("created_at", 0)),
        )


class PMTECServer:
    """PMTEC gRPC Server - hosts all DTB Model services."""

    def __init__(self, host: str = GRPC_HOST, port: int = GRPC_PORT):
        self.host = host
        self.port = port
        self.engine = PMTECEngine()
        self._server: Optional[grpc.Server] = None

    def start(self):
        """Start the gRPC server with all DTB services."""
        self._server = grpc.server(futures.ThreadPoolExecutor(max_workers=10))
        pb_grpc.add_WarEngineServicer_to_server(
            WarEngineServicer(self.engine), self._server
        )
        pb_grpc.add_BattleNetworkServicer_to_server(
            BattleNetworkServicer(self.engine), self._server
        )
        pb_grpc.add_ApplicationStoreServicer_to_server(
            ApplicationStoreServicer(self.engine), self._server
        )
        pb_grpc.add_PlugAndPlayServicer_to_server(
            PlugAndPlayServicer(self.engine), self._server
        )
        self._server.add_insecure_port(f"{self.host}:{self.port}")
        self._server.start()
        return True

    def stop(self):
        if self._server:
            self.engine.stop_simulation()
            self._server.stop(grace=2)
        return True

    def wait_for_termination(self):
        if self._server:
            self._server.wait_for_termination()

    @property
    def address(self) -> str:
        return f"{self.host}:{self.port}"
