"""
LVC Architecture - Live/Virtual/Constructive layer management for PMTEC.
DTB Model: War Engine (LVC coordination) + Plug-and-Play (layer composition)
"""

import math
import random
from dataclasses import dataclass, field
from typing import Optional
from config import EARTH_RADIUS_KM


@dataclass
class LVCLayer:
    layer_name: str  # "Live", "Virtual", "Constructive"
    enabled: bool = True
    entity_count: int = 0
    entities: list = field(default_factory=list)
    description: str = ""

    def add_entity(self, entity):
        self.entities.append(entity)
        self.entity_count = len(self.entities)

    def remove_entity(self, entity_id: str):
        self.entities = [e for e in self.entities if getattr(e, "id", "") != entity_id]
        self.entity_count = len(self.entities)

    def get_entities(self, entity_type: str = None) -> list:
        if entity_type:
            return [
                e for e in self.entities if getattr(e, "entity_type", "") == entity_type
            ]
        return self.entities

    def to_dict(self) -> dict:
        return {
            "layer": self.layer_name,
            "enabled": self.enabled,
            "entity_count": self.entity_count,
            "description": self.description,
        }


class LVCArchitecture:
    """
    PMTEC LVC (Live-Virtual-Constructive) Architecture Manager.

    - Live: Real-world entities (actual bases, sensor feeds, real tracks)
    - Virtual: Simulated entities (CGF - computer-generated forces)
    - Constructive: Aggregate-level command simulation (ASDA decisions)
    """

    def __init__(self):
        self.live = LVCLayer(
            layer_name="Live",
            description="Real-world data feeds: base positions, sensor networks, actual track data",
        )
        self.virtual = LVCLayer(
            layer_name="Virtual",
            description="Computer-generated forces: simulated aircraft, missiles, with physics models",
        )
        self.constructive = LVCLayer(
            layer_name="Constructive",
            description="Aggregate command-level simulation: ASDA decisions, ACE deployment algorithms",
        )
        self._fusion_buffer: list = []

    @property
    def layers(self) -> list[LVCLayer]:
        return [self.live, self.virtual, self.constructive]

    def total_entities(self) -> int:
        return sum(l.entity_count for l in self.layers if l.enabled)

    def all_entities(self) -> list:
        result = []
        for layer in self.layers:
            if layer.enabled:
                result.extend(layer.entities)
        return result

    def get_layer(self, name: str) -> Optional[LVCLayer]:
        for layer in self.layers:
            if layer.layer_name.lower() == name.lower():
                return layer
        return None

    def inject_track(self, track_data: dict, source_layer: str = "Virtual"):
        """Inject a sensor track into the fusion buffer."""
        track_data["source_layer"] = source_layer
        self._fusion_buffer.append(track_data)

    def fuse_tracks(self) -> list:
        """Fuse tracks from multiple LVC layers into a unified track picture."""
        if not self._fusion_buffer:
            return []
        # Group by proximity (simplified fusion)
        fused = []
        used = set()
        for i, t in enumerate(self._fusion_buffer):
            if i in used:
                continue
            merged = dict(t)
            confidence = t.get("confidence", 0.5)
            source_count = 1
            for j in range(i + 1, len(self._fusion_buffer)):
                if j in used:
                    continue
                t2 = self._fusion_buffer[j]
                dist = haversine(
                    t.get("lat", 0), t.get("lon", 0), t2.get("lat", 0), t2.get("lon", 0)
                )
                if dist < 5.0:  # within 5km - same track
                    # Merge: average position, max confidence
                    merged["lat"] = (merged.get("lat", 0) + t2.get("lat", 0)) / 2
                    merged["lon"] = (merged.get("lon", 0) + t2.get("lon", 0)) / 2
                    confidence = max(confidence, t2.get("confidence", 0))
                    source_count += 1
                    used.add(j)
            merged["confidence"] = min(1.0, confidence + 0.1 * (source_count - 1))
            merged["source_count"] = source_count
            fused.append(merged)
            used.add(i)
        self._fusion_buffer.clear()
        return fused

    def status(self) -> dict:
        return {
            "total_entities": self.total_entities(),
            "layers": [l.to_dict() for l in self.layers],
            "fusion_buffer_size": len(self._fusion_buffer),
        }


def haversine(lat1, lon1, lat2, lon2) -> float:
    """Distance in km between two coordinates."""
    lat1, lon1, lat2, lon2 = map(math.radians, [lat1, lon1, lat2, lon2])
    dlat = lat2 - lat1
    dlon = lon2 - lon1
    a = (
        math.sin(dlat / 2) ** 2
        + math.cos(lat1) * math.cos(lat2) * math.sin(dlon / 2) ** 2
    )
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
    return EARTH_RADIUS_KM * c
