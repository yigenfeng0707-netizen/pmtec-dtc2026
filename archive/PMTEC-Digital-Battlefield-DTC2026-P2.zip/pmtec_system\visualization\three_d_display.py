"""
3D Battlefield Visualization - Three.js WebGL2 based 3D view.
2D/3D toggle, synthetic terrain, entity models, trajectory/ballistic rendering.
Pure browser WebGL2, no GPU driver dependency (Intel Arc compatible).
"""

import json
import os
from typing import Optional
from config import OUTPUT_DIR


class ThreeDDisplay:
    """Generates 3D battlefield visualization HTML with Three.js."""

    def __init__(self):
        self._bases: list[dict] = []
        self._load_bases()

    def _load_bases(self):
        geojson_path = os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
            "data",
            "bases.geojson",
        )
        if not os.path.exists(geojson_path):
            return
        with open(geojson_path, "r", encoding="utf-8") as f:
            data = json.load(f)
        for feat in data.get("features", []):
            props = feat.get("properties", {})
            coords = feat.get("geometry", {}).get("coordinates", [0, 0])
            self._bases.append(
                {
                    "id": props.get("base_id", props.get("name", "")),
                    "name": props.get("name", ""),
                    "lat": coords[1] if len(coords) >= 2 else 0,
                    "lon": coords[0] if len(coords) >= 2 else 0,
                    "is_ace_hub": props.get("is_ace_hub", False),
                }
            )

    def generate_html(
        self, state: dict, events: list = None, output_path: str = None
    ) -> str:
        """Generate 3D visualization HTML from simulation state."""
        if not output_path:
            os.makedirs(OUTPUT_DIR, exist_ok=True)
            output_path = os.path.join(OUTPUT_DIR, "pmtec_3d_display.html")

        entities = state.get("entities", [])
        tracks = state.get("tracks", [])
        bases_js = json.dumps(self._bases, ensure_ascii=False)
        entities_js = json.dumps(entities, ensure_ascii=False)
        tracks_js = json.dumps(tracks, ensure_ascii=False)

        html = _THREE_D_TEMPLATE
        html = html.replace("__BASES__", bases_js)
        html = html.replace("__ENTITIES__", entities_js)
        html = html.replace("__TRACKS__", tracks_js)
        html = html.replace("__SIM_TIME__", str(state.get("sim_time", "T+00:00:00")))
        html = html.replace("__ASDA_CYCLE__", str(state.get("asda_cycle", 0)))
        html = html.replace("__ASDA_PHASE__", str(state.get("asda_phase", "idle")))

        with open(output_path, "w", encoding="utf-8") as f:
            f.write(html)
        return output_path


_THREE_D_TEMPLATE = r"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<title>PMTEC 3D Battlefield - DTC 2026 P0</title>
<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body { background: #0a0e1a; color: #c0c8d8; font-family: 'Courier New', monospace; overflow: hidden; }
  #header { background: linear-gradient(135deg, #0d1b2a, #1b263b); padding: 8px 16px;
             border-bottom: 2px solid #415977; display: flex; justify-content: space-between; align-items: center; }
  #header h1 { color: #4e9af5; font-size: 16px; }
  #header .status { display: flex; gap: 12px; font-size: 12px; }
  .badge { padding: 3px 8px; border-radius: 4px; font-size: 11px; font-weight: bold; }
  .badge-time { background: #2a1a1a; color: #f59e4e; border: 1px solid #6a3a1a; }
  .badge-asda { background: #1a4a2a; color: #4e9af5; border: 1px solid #2a6a3a; }
  #canvas3d { width: 100%; height: calc(100vh - 50px); display: block; }
  #info { position: absolute; top: 60px; right: 16px; background: rgba(10,14,26,0.9);
           padding: 10px; border-radius: 4px; border: 1px solid #333; font-size: 11px; max-width: 250px; }
  #info h3 { color: #4e9af5; font-size: 12px; margin-bottom: 6px; }
  #loading { position: absolute; top: 50%; left: 50%; transform: translate(-50%,-50%);
              color: #4e9af5; font-size: 18px; }
</style>
</head>
<body>
<div id="header">
  <h1>PMTEC 3D Battlefield - Three.js WebGL2</h1>
  <div class="status">
    <span class="badge badge-time">SIM: __SIM_TIME__</span>
    <span class="badge badge-asda">ASDA #__ASDA_CYCLE__ | __ASDA_PHASE__</span>
    <span class="badge badge-asda">3D Mode (Intel Arc WebGL2)</span>
  </div>
</div>
<canvas id="canvas3d"></canvas>
<div id="info">
  <h3>3D Battlefield View</h3>
  <div style="line-height:1.6;">
    <div style="color:#4e9af5;">Controls:</div>
    <div>Mouse: Rotate | Scroll: Zoom | Right-drag: Pan</div>
    <div style="color:#4e9af5;margin-top:4px;">Layers:</div>
    <div style="color:#4ef59e;">Green: Bases (ACE Hub = larger)</div>
    <div style="color:#4e9af5;">Blue: Friendly aircraft</div>
    <div style="color:#f54e4e;">Red: Hostile missiles</div>
    <div style="color:#f5e44e;">Yellow: Sensor tracks</div>
    <div style="color:#9e4ef5;margin-top:4px;">Trajectories:</div>
    <div>Arc lines show flight paths</div>
    <div style="color:#4ef5d4;">Cyan: Sensor coverage</div>
  </div>
</div>
<div id="loading">Initializing 3D scene...</div>
<script src="https://unpkg.com/three@0.160.0/build/three.min.js"></script>
<script>
var bases = __BASES__;
var entities = __ENTITIES__;
var tracks = __TRACKS__;

var scene, camera, renderer, controls;
var entityMeshes = {};
var trackMeshes = {};

function latLonTo3D(lat, lon, alt) {
  var radius = 6371;
  var phi = (90 - lat) * Math.PI / 180;
  var theta = (lon + 180) * Math.PI / 180;
  var r = radius + (alt || 0) / 1000;
  return new THREE.Vector3(
    -r * Math.sin(phi) * Math.cos(theta),
    r * Math.cos(phi),
    r * Math.sin(phi) * Math.sin(theta)
  );
}

function init() {
  scene = new THREE.Scene();
  scene.background = new THREE.Color(0x0a0e1a);
  scene.fog = new THREE.Fog(0x0a0e1a, 3000, 15000);

  camera = new THREE.PerspectiveCamera(60, window.innerWidth / (window.innerHeight - 50), 0.1, 50000);
  camera.position.set(0, 3000, 5000);
  camera.lookAt(0, 0, 0);

  renderer = new THREE.WebGLRenderer({
    canvas: document.getElementById('canvas3d'),
    antialias: true
  });
  renderer.setSize(window.innerWidth, window.innerHeight - 50);
  renderer.setPixelRatio(window.devicePixelRatio);

  var ambient = new THREE.AmbientLight(0x404060, 0.5);
  scene.add(ambient);
  var dirLight = new THREE.DirectionalLight(0xffffff, 0.8);
  dirLight.position.set(5000, 5000, 5000);
  scene.add(dirLight);

  var gridHelper = new THREE.GridHelper(10000, 50, 0x1a3a5a, 0x0d1b2a);
  gridHelper.rotation.x = Math.PI / 2;
  scene.add(gridHelper);

  addTerrain();
  addBases();
  addEntities();
  addTracks();
  addTrajectories();

  document.getElementById('loading').style.display = 'none';

  animate();
  window.addEventListener('resize', onResize);
  
  // Simple orbit controls
  var isDragging = false;
  var prevMouse = {x:0, y:0};
  var canvas = document.getElementById('canvas3d');
  canvas.addEventListener('mousedown', function(e) {
    isDragging = true;
    prevMouse = {x: e.clientX, y: e.clientY};
  });
  canvas.addEventListener('mousemove', function(e) {
    if (!isDragging) return;
    var dx = e.clientX - prevMouse.x;
    var dy = e.clientY - prevMouse.y;
    var radius = camera.position.length();
    var theta = Math.atan2(camera.position.x, camera.position.z) + dx * 0.005;
    var phi = Math.acos(camera.position.y / radius) - dy * 0.005;
    phi = Math.max(0.1, Math.min(Math.PI - 0.1, phi));
    camera.position.x = radius * Math.sin(phi) * Math.sin(theta);
    camera.position.y = radius * Math.cos(phi);
    camera.position.z = radius * Math.sin(phi) * Math.cos(theta);
    camera.lookAt(0, 0, 0);
    prevMouse = {x: e.clientX, y: e.clientY};
  });
  canvas.addEventListener('mouseup', function() { isDragging = false; });
  canvas.addEventListener('wheel', function(e) {
    e.preventDefault();
    var scale = e.deltaY > 0 ? 1.1 : 0.9;
    camera.position.multiplyScalar(scale);
  });
}

function addTerrain() {
  var geo = new THREE.SphereGeometry(6371, 64, 32);
  var mat = new THREE.MeshPhongMaterial({
    color: 0x1a2a3a,
    transparent: true,
    opacity: 0.3,
    wireframe: false
  });
  var mesh = new THREE.Mesh(geo, mat);
  scene.add(mesh);
  
  var wireGeo = new THREE.SphereGeometry(6371, 32, 16);
  var wireMat = new THREE.MeshBasicMaterial({
    color: 0x2a4a6a,
    wireframe: true,
    transparent: true,
    opacity: 0.15
  });
  scene.add(new THREE.Mesh(wireGeo, wireMat));
}

function addBases() {
  bases.forEach(function(b) {
    var pos = latLonTo3D(b.lat, b.lon, 0);
    var size = b.is_ace_hub ? 30 : 15;
    var geo = new THREE.ConeGeometry(size, size * 2, 8);
    var mat = new THREE.MeshPhongMaterial({
      color: b.is_ace_hub ? 0x00ff88 : 0x4e9af5,
      emissive: b.is_ace_hub ? 0x004422 : 0x001122
    });
    var mesh = new THREE.Mesh(geo, mat);
    mesh.position.copy(pos);
    mesh.lookAt(0, 0, 0);
    mesh.rotateX(Math.PI / 2);
    scene.add(mesh);
  });
}

function addEntities() {
  entities.forEach(function(e) {
    var pos = latLonTo3D(e.lat, e.lon, e.alt_m || 10000);
    var geo, mat, color;
    if (e.type === 'missile') {
      color = 0xff4444;
      geo = new THREE.ConeGeometry(8, 20, 6);
      mat = new THREE.MeshPhongMaterial({color: color, emissive: 0x440000});
    } else if (e.type === 'sensor') {
      color = 0x4ef59e;
      geo = new THREE.OctahedronGeometry(10);
      mat = new THREE.MeshPhongMaterial({color: color, emissive: 0x004422});
    } else {
      color = e.affiliation === 'hostile' ? 0xff4444 : 0x4e9af5;
      geo = new THREE.BoxGeometry(12, 4, 12);
      mat = new THREE.MeshPhongMaterial({color: color, emissive: 0x001133});
    }
    var mesh = new THREE.Mesh(geo, mat);
    mesh.position.copy(pos);
    mesh.lookAt(0, 0, 0);
    scene.add(mesh);
    entityMeshes[e.id] = mesh;

    // Add glow sprite
    var glowGeo = new THREE.SphereGeometry(15, 8, 8);
    var glowMat = new THREE.MeshBasicMaterial({
      color: color, transparent: true, opacity: 0.2
    });
    var glow = new THREE.Mesh(glowGeo, glowMat);
    glow.position.copy(pos);
    scene.add(glow);
  });
}

function addTracks() {
  tracks.forEach(function(t) {
    var pos = latLonTo3D(t.lat, t.lon, t.alt_m || 5000);
    var geo = new THREE.SphereGeometry(6, 8, 6);
    var mat = new THREE.MeshBasicMaterial({
      color: 0xf5e44e, transparent: true, opacity: 0.5
    });
    var mesh = new THREE.Mesh(geo, mat);
    mesh.position.copy(pos);
    scene.add(mesh);
    trackMeshes[t.track_id] = mesh;
  });
}

function addTrajectories() {
  entities.forEach(function(e) {
    if (e.type === 'missile' && e.speed_kmh > 0) {
      var startPos = latLonTo3D(e.lat, e.lon, e.alt_m || 50000);
      var targetPos = latLonTo3D(e.lat + 5, e.lon + 5, 0);
      var curve = new THREE.QuadraticBezierCurve3(startPos, 
        new THREE.Vector3((startPos.x + targetPos.x) / 2, 
          (startPos.y + targetPos.y) / 2 + 200, 
          (startPos.z + targetPos.z) / 2), targetPos);
      var points = curve.getPoints(20);
      var geo = new THREE.BufferGeometry().setFromPoints(points);
      var mat = new THREE.LineBasicMaterial({color: 0xff4444, transparent: true, opacity: 0.4});
      scene.add(new THREE.Line(geo, mat));
    }
  });
}

function animate() {
  requestAnimationFrame(animate);
  Object.keys(entityMeshes).forEach(function(id) {
    var mesh = entityMeshes[id];
    mesh.rotation.y += 0.02;
  });
  renderer.render(scene, camera);
}

function onResize() {
  camera.aspect = window.innerWidth / (window.innerHeight - 50);
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight - 50);
}

init();
</script>
</body>
</html>"""
