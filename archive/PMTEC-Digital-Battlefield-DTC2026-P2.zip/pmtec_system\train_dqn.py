#!/usr/bin/env python3
"""
DQN Training Script - Trains a Deep Q-Network agent on the PMTEC environment.
Each episode = one simulation run (120s = 12 ASDA cycles).

P2: Supports XPU (Intel Arc GPU) acceleration via --device auto|xpu:0|cpu.

Run with CPU:  python train_dqn.py --timesteps 5000
Run with XPU:  python train_dqn.py --timesteps 5000 --device xpu:0
Auto-detect:   python train_dqn.py --timesteps 5000 --device auto
"""

import sys
import os
import time
import json
import argparse
import numpy as np

# Ensure project root in path
PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from deep_rl.pmtec_env import PMTECEnv
from deep_rl.dqn_agent import DQNAgent, detect_best_device


def evaluate_agent(agent: DQNAgent, env: PMTECEnv, n_episodes: int = 5):
    """Evaluate trained agent: run episodes with deterministic policy."""
    results = []
    for ep in range(n_episodes):
        obs, _ = env.reset(seed=42 + ep)
        total_reward = 0.0
        done = False
        while not done:
            action = agent.predict(obs, deterministic=True)
            obs, reward, done, _, info = env.step(action)
            total_reward += reward
        results.append(
            {
                "episode": ep,
                "total_reward": round(total_reward, 2),
                "intercept_rate": round(info.get("intercept_rate", 0), 3),
                "aircraft_destroyed": info.get("destroyed_aircraft", 0),
                "aircraft_survived": info.get("active_aircraft", 0),
                "missiles_intercepted": info.get("intercepted_missiles", 0),
            }
        )
    return results


def main():
    parser = argparse.ArgumentParser(description="Train DQN for PMTEC ASDA")
    parser.add_argument(
        "--timesteps",
        type=int,
        default=5000,
        help="Total training timesteps (default: 5000)",
    )
    parser.add_argument(
        "--duration",
        type=int,
        default=120,
        help="Episode duration in seconds (default: 120)",
    )
    parser.add_argument(
        "--lr", type=float, default=1e-4, help="Learning rate (default: 1e-4)"
    )
    parser.add_argument(
        "--eval-only",
        action="store_true",
        help="Skip training, only evaluate existing model",
    )
    parser.add_argument(
        "--device",
        type=str,
        default="auto",
        choices=["auto", "cpu", "xpu:0", "cuda:0"],
        help="Compute device: auto (detect), cpu, xpu:0 (Intel Arc), cuda:0 (NVIDIA)",
    )
    parser.add_argument("--seed", type=int, default=42, help="Random seed")
    args = parser.parse_args()

    # Resolve device
    device = args.device
    if device == "auto":
        device = detect_best_device()

    print("=" * 70)
    print("PMTEC DQN Training - Deep Reinforcement Learning for ASDA")
    print(f"Algorithm: DQN (stable_baselines3 + PyTorch)")
    print(f"Device: {device}")
    if "xpu" in device:
        import torch

        print(f"  GPU: {torch.xpu.get_device_name(0)}")
        print(
            f"  Memory: {torch.xpu.get_device_properties(0).total_memory / 1e9:.2f} GB"
        )
    print("=" * 70)

    # Create environment
    env = PMTECEnv(duration=args.duration, seed=args.seed)
    print(
        f"Environment: PMTECEnv | obs_dim={env.observation_space.shape[0]} | actions={env.action_space.n}"
    )
    print(f"Episode: {args.duration}s = {args.duration // 10} ASDA cycles")
    print()

    # Create agent with selected device
    agent = DQNAgent(learning_rate=args.lr, device=device)

    if not args.eval_only:
        # Train
        print(f"Training DQN for {args.timesteps} timesteps...")
        result = agent.train(env, total_timesteps=args.timesteps)
        print()

    # Evaluate
    print("Evaluating trained agent (5 episodes, deterministic)...")
    eval_results = evaluate_agent(agent, env, n_episodes=5)
    print()
    print(
        f"{'Ep':>3} {'Reward':>8} {'IntRate':>8} {'Survived':>9} {'Destroyed':>10} {'Intercepted':>12}"
    )
    print("-" * 55)
    for r in eval_results:
        print(
            f"{r['episode']:>3} {r['total_reward']:>8.1f} {r['intercept_rate']:>8.1%} "
            f"{r['aircraft_survived']:>9} {r['aircraft_destroyed']:>10} {r['missiles_intercepted']:>12}"
        )
    avg_reward = np.mean([r["total_reward"] for r in eval_results])
    avg_ir = np.mean([r["intercept_rate"] for r in eval_results])
    avg_surv = np.mean([r["aircraft_survived"] for r in eval_results])
    print("-" * 55)
    print(f"AVG {avg_reward:>8.1f} {avg_ir:>8.1%} {avg_surv:>9.0f}")
    print()

    # Save evaluation results
    stats = agent.get_statistics()
    print("Agent statistics:")
    for k, v in stats.items():
        print(f"  {k}: {v}")
    print()
    print("=" * 70)
    print("DQN training complete. Model ready for PMTEC integration.")
    print(f"Model path: {agent.model_path}")
    print("=" * 70)


if __name__ == "__main__":
    main()
