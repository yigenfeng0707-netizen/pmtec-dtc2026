"""
3D Battlefield Visualization - Enhanced Three.js WebGL2 based 3D view (P4-3).

Features:
  - Real-time entity tracking with position interpolation
  - Missile ballistic trajectory animation (arc paths)
  - Sensor coverage hemisphere visualization
  - EW jamming zone rendering (semi-transparent spheres)
  - Cyber attack effect visualization
  - Kalman track confidence heatmap (green=high, yellow=medium, red=low)
  - Weather overlay (cloud/rain visualization)
  - Auto-refresh support for live state updates

Pure browser WebGL2, no GPU driver dependency (Intel Arc compatible).
"""

import json
import os
from typing import Optional
from config import OUTPUT_DIR


class ThreeDDisplay:
    """Generates enhanced 3D battlefield visualization HTML with Three.js."""

    def __init__(self):
        self._bases: list[dict] = []
        self._load_bases()

    def _load_bases(self):
        geojson_path = os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
            "data",
            "bases.geojson",
        )
        if not os.path.exists(geojson_path):
            return
        with open(geojson_path, "r", encoding="utf-8") as f:
            data = json.load(f)
        for feat in data.get("features", []):
            props = feat.get("properties", {})
            coords = feat.get("geometry", {}).get("coordinates", [0, 0])
            self._bases.append(
                {
                    "id": props.get("base_id", props.get("name", "")),
                    "name": props.get("name", ""),
                    "lat": coords[1] if len(coords) >= 2 else 0,
                    "lon": coords[0] if len(coords) >= 2 else 0,
                    "is_ace_hub": props.get("is_ace_hub", False),
                }
            )

    def generate_html(
        self, state: dict, events: list = None, output_path: str = None
    ) -> str:
        """Generate enhanced 3D visualization HTML from simulation state.

        P4-3 enhancements: sensor domes, EW zones, missile arcs,
        Kalman confidence heatmap, weather overlay, cyber effects.
        """
        if not output_path:
            os.makedirs(OUTPUT_DIR, exist_ok=True)
            output_path = os.path.join(OUTPUT_DIR, "pmtec_3d_display.html")

        entities = state.get("entities", [])
        tracks = state.get("tracks", [])

        # P4-3: Extract specialized entity types from mixed entity list
        sensors = [
            e
            for e in entities
            if e.get("type") == "sensor" or e.get("detection_range_km", 0) > 0
        ]
        ew_threats = [
            e
            for e in entities
            if e.get("subtype")
            and "ew" in str(e.get("subtype", "")).lower()
            or e.get("jam_range_km", 0) > 0
        ]
        cyber_threats = [
            e
            for e in entities
            if e.get("subtype")
            and "cyber" in str(e.get("subtype", "")).lower()
            or e.get("phase", "")
            in ("infiltration", "persistence", "impact", "remediated")
        ]
        missiles = [e for e in entities if e.get("type") == "missile"]
        aircraft = [
            e
            for e in entities
            if e.get("type") not in ("missile", "sensor")
            and not e.get("detection_range_km")
        ]

        # Kalman tracks from LVC (if available in state)
        kalman_tracks = state.get("kalman_tracks", [])
        if not kalman_tracks:
            # Use regular tracks as fallback
            kalman_tracks = tracks

        # Weather info
        weather = state.get("weather", {})
        if not weather and "live_data_stats" in state:
            weather = state.get("live_data_stats", {})

        # Persistence summary (P4-1)
        persistence = state.get("persistence", {})

        # Adversary stats (P3-4)
        adversary = state.get("adversary_stats", {})

        bases_js = json.dumps(self._bases, ensure_ascii=False)
        aircraft_js = json.dumps(aircraft, ensure_ascii=False)
        missiles_js = json.dumps(missiles, ensure_ascii=False)
        sensors_js = json.dumps(sensors, ensure_ascii=False)
        ew_js = json.dumps(ew_threats, ensure_ascii=False)
        cyber_js = json.dumps(cyber_threats, ensure_ascii=False)
        kalman_js = json.dumps(kalman_tracks, ensure_ascii=False)
        tracks_js = json.dumps(tracks, ensure_ascii=False)
        weather_js = json.dumps(weather, ensure_ascii=False)
        adversary_js = json.dumps(adversary, ensure_ascii=False)
        persistence_js = json.dumps(persistence, ensure_ascii=False)

        html = _THREE_D_TEMPLATE_P4
        html = html.replace("__BASES__", bases_js)
        html = html.replace("__AIRCRAFT__", aircraft_js)
        html = html.replace("__MISSILES__", missiles_js)
        html = html.replace("__SENSORS__", sensors_js)
        html = html.replace("__EW_THREATS__", ew_js)
        html = html.replace("__CYBER_THREATS__", cyber_js)
        html = html.replace("__KALMAN_TRACKS__", kalman_js)
        html = html.replace("__TRACKS__", tracks_js)
        html = html.replace("__WEATHER__", weather_js)
        html = html.replace("__ADVERSARY__", adversary_js)
        html = html.replace("__PERSISTENCE__", persistence_js)
        html = html.replace("__SIM_TIME__", str(state.get("sim_time", "T+00:00:00")))
        html = html.replace("__SIM_SECONDS__", str(state.get("sim_seconds", 0)))
        html = html.replace("__ASDA_CYCLE__", str(state.get("asda_cycle", 0)))
        html = html.replace("__ASDA_PHASE__", str(state.get("asda_phase", "idle")))
        html = html.replace("__TOTAL_ENTITIES__", str(state.get("total_entities", 0)))
        html = html.replace("__ACTIVE_TRACKS__", str(state.get("active_tracks", 0)))
        html = html.replace(
            "__NETWORK_VULN__", str(state.get("network_vulnerability", 0))
        )
        html = html.replace("__LVC_LIVE__", str(state.get("lvc_live_entities", 0)))

        with open(output_path, "w", encoding="utf-8") as f:
            f.write(html)
        return output_path


_THREE_D_TEMPLATE_P4 = r"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<title>PMTEC 3D Battlefield - DTC 2026 P4 Enhanced</title>
<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body { background: #0a0e1a; color: #c0c8d8; font-family: 'Courier New', monospace; overflow: hidden; }
  #header { background: linear-gradient(135deg, #0d1b2a, #1b263b); padding: 8px 16px;
             border-bottom: 2px solid #415977; display: flex; justify-content: space-between; align-items: center; }
  #header h1 { color: #4e9af5; font-size: 16px; }
  #header .status { display: flex; gap: 8px; font-size: 11px; flex-wrap: wrap; }
  .badge { padding: 3px 8px; border-radius: 4px; font-size: 10px; font-weight: bold; }
  .badge-time { background: #2a1a1a; color: #f59e4e; border: 1px solid #6a3a1a; }
  .badge-asda { background: #1a4a2a; color: #4e9af5; border: 1px solid #2a6a3a; }
  .badge-vuln { background: #1a1a2a; color: #f54e4e; border: 1px solid #3a1a1a; }
  .badge-p4 { background: #2a1a3a; color: #c24ef5; border: 1px solid #4a2a6a; }
  #canvas3d { width: 100%; height: calc(100vh - 50px); display: block; }
  #legend { position: absolute; top: 60px; right: 16px; background: rgba(10,14,26,0.92);
             padding: 12px; border-radius: 4px; border: 1px solid #333; font-size: 11px; max-width: 280px; z-index: 10; }
  #legend h3 { color: #4e9af5; font-size: 12px; margin-bottom: 8px; }
  #legend .section { margin-top: 8px; padding-top: 6px; border-top: 1px solid #222; }
  #legend .item { display: flex; align-items: center; gap: 6px; margin: 3px 0; }
  #legend .dot { width: 10px; height: 10px; border-radius: 50%; flex-shrink: 0; }
  #stats { position: absolute; bottom: 16px; left: 16px; background: rgba(10,14,26,0.92);
           padding: 10px; border-radius: 4px; border: 1px solid #333; font-size: 11px; z-index: 10; }
  #stats .row { display: flex; justify-content: space-between; gap: 12px; margin: 2px 0; }
  #stats .label { color: #6a7a8a; }
  #stats .value { color: #4e9af5; font-weight: bold; }
  #loading { position: absolute; top: 50%; left: 50%; transform: translate(-50%,-50%);
              color: #4e9af5; font-size: 18px; z-index: 20; }
  .toggle-btn { padding: 4px 8px; border: 1px solid #415977; border-radius: 3px; cursor: pointer;
                font-size: 10px; margin: 2px; display: inline-block; }
  .toggle-btn.active { background: #1a4a2a; color: #4e9af5; }
  .toggle-btn:hover { background: #2a3a4a; }
</style>
</head>
<body>
<div id="header">
  <h1>PMTEC 3D Battlefield - P4 Enhanced (Three.js WebGL2)</h1>
  <div class="status">
    <span class="badge badge-time">SIM: __SIM_TIME__</span>
    <span class="badge badge-asda">ASDA #__ASDA_CYCLE__ | __ASDA_PHASE__</span>
    <span class="badge badge-vuln">Vuln: __NETWORK_VULN__</span>
    <span class="badge badge-p4">P4 Enhanced</span>
  </div>
</div>
<canvas id="canvas3d"></canvas>
<div id="legend">
  <h3>3D Tactical Display</h3>
  <div class="section">
    <div class="item"><div class="dot" style="background:#00ff88;"></div>ACE Hub Base</div>
    <div class="item"><div class="dot" style="background:#4e9af5;"></div>Friendly Aircraft</div>
    <div class="item"><div class="dot" style="background:#ff4444;"></div>Hostile Missile</div>
  </div>
  <div class="section">
    <div class="item"><div class="dot" style="background:#4ef59e;opacity:0.3;"></div>Sensor Dome (coverage)</div>
    <div class="item"><div class="dot" style="background:#f5a04e;opacity:0.3;"></div>EW Jamming Zone</div>
    <div class="item"><div class="dot" style="background:#a04ef5;opacity:0.3;"></div>Cyber Attack Zone</div>
  </div>
  <div class="section">
    <div class="item"><div class="dot" style="background:#00ff00;"></div>Kalman Track (high conf)</div>
    <div class="item"><div class="dot" style="background:#ffcc00;"></div>Kalman Track (medium)</div>
    <div class="item"><div class="dot" style="background:#ff4444;"></div>Kalman Track (low conf)</div>
  </div>
  <div class="section">
    <div>Missile: animated arc trajectory</div>
    <div>Weather: cloud overlay when active</div>
  </div>
  <div class="section">
    <span class="toggle-btn active" id="toggle-sensors" onclick="toggleLayer('sensors')">Sensors</span>
    <span class="toggle-btn active" id="toggle-ew" onclick="toggleLayer('ew')">EW Zones</span>
    <span class="toggle-btn active" id="toggle-cyber" onclick="toggleLayer('cyber')">Cyber</span>
    <span class="toggle-btn active" id="toggle-kalman" onclick="toggleLayer('kalman')">Kalman</span>
    <span class="toggle-btn active" id="toggle-trajectory" onclick="toggleLayer('trajectory')">Trajectories</span>
    <span class="toggle-btn active" id="toggle-weather" onclick="toggleLayer('weather')">Weather</span>
  </div>
</div>
<div id="stats">
  <div class="row"><span class="label">Entities:</span><span class="value">__TOTAL_ENTITIES__</span></div>
  <div class="row"><span class="label">Active Tracks:</span><span class="value">__ACTIVE_TRACKS__</span></div>
  <div class="row"><span class="label">LVC Live:</span><span class="value">__LVC_LIVE__</span></div>
  <div class="row"><span class="label">Sim Time:</span><span class="value">__SIM_SECONDS__s</span></div>
</div>
<div id="loading">Initializing P4 Enhanced 3D scene...</div>
<script src="https://unpkg.com/three@0.160.0/build/three.min.js"></script>
<script>
var bases = __BASES__;
var aircraft = __AIRCRAFT__;
var missiles = __MISSILES__;
var sensors = __SENSORS__;
var ewThreats = __EW_THREATS__;
var cyberThreats = __CYBER_THREATS__;
var kalmanTracks = __KALMAN_TRACKS__;
var tracks = __TRACKS__;
var weather = __WEATHER__;
var adversary = __ADVERSARY__;
var persistence = __PERSISTENCE__;

var scene, camera, renderer;
var entityMeshes = {};
var layerGroups = {
  sensors: null, ew: null, cyber: null,
  kalman: null, trajectory: null, weather: null
};
var layerVisible = {
  sensors: true, ew: true, cyber: true,
  kalman: true, trajectory: true, weather: true
};
var animTime = 0;

function latLonTo3D(lat, lon, alt) {
  var radius = 6371;
  var phi = (90 - lat) * Math.PI / 180;
  var theta = (lon + 180) * Math.PI / 180;
  var r = radius + (alt || 0) / 1000;
  return new THREE.Vector3(
    -r * Math.sin(phi) * Math.cos(theta),
    r * Math.cos(phi),
    r * Math.sin(phi) * Math.sin(theta)
  );
}

function confidenceColor(conf) {
  if (conf >= 0.7) return 0x00ff00;
  if (conf >= 0.4) return 0xffcc00;
  return 0xff4444;
}

function toggleLayer(name) {
  layerVisible[name] = !layerVisible[name];
  var btn = document.getElementById('toggle-' + name);
  if (btn) btn.classList.toggle('active');
  if (layerGroups[name]) layerGroups[name].visible = layerVisible[name];
}

function init() {
  scene = new THREE.Scene();
  scene.background = new THREE.Color(0x0a0e1a);
  scene.fog = new THREE.Fog(0x0a0e1a, 3000, 15000);

  camera = new THREE.PerspectiveCamera(60, window.innerWidth / (window.innerHeight - 50), 0.1, 50000);
  camera.position.set(0, 3000, 5000);
  camera.lookAt(0, 0, 0);

  renderer = new THREE.WebGLRenderer({
    canvas: document.getElementById('canvas3d'),
    antialias: true
  });
  renderer.setSize(window.innerWidth, window.innerHeight - 50);
  renderer.setPixelRatio(window.devicePixelRatio);

  var ambient = new THREE.AmbientLight(0x404060, 0.5);
  scene.add(ambient);
  var dirLight = new THREE.DirectionalLight(0xffffff, 0.8);
  dirLight.position.set(5000, 5000, 5000);
  scene.add(dirLight);

  // Terrain
  var geo = new THREE.SphereGeometry(6371, 64, 32);
  var mat = new THREE.MeshPhongMaterial({ color: 0x1a2a3a, transparent: true, opacity: 0.3 });
  scene.add(new THREE.Mesh(geo, mat));
  var wireGeo = new THREE.SphereGeometry(6371, 32, 16);
  var wireMat = new THREE.MeshBasicMaterial({ color: 0x2a4a6a, wireframe: true, transparent: true, opacity: 0.15 });
  scene.add(new THREE.Mesh(wireGeo, wireMat));

  // Grid
  var grid = new THREE.GridHelper(10000, 50, 0x1a3a5a, 0x0d1b2a);
  grid.rotation.x = Math.PI / 2;
  scene.add(grid);

  addBases();
  addAircraft();
  addMissiles();
  addSensorDomes();
  addEWZones();
  addCyberZones();
  addKalmanTracks();
  addTrajectories();
  addWeatherOverlay();

  document.getElementById('loading').style.display = 'none';
  animate();

  // Orbit controls
  var isDragging = false, prevMouse = {x:0, y:0};
  var canvas = document.getElementById('canvas3d');
  canvas.addEventListener('mousedown', function(e) {
    isDragging = true; prevMouse = {x: e.clientX, y: e.clientY};
  });
  canvas.addEventListener('mousemove', function(e) {
    if (!isDragging) return;
    var dx = e.clientX - prevMouse.x, dy = e.clientY - prevMouse.y;
    var radius = camera.position.length();
    var theta = Math.atan2(camera.position.x, camera.position.z) + dx * 0.005;
    var phi = Math.acos(Math.max(-1, Math.min(1, camera.position.y / radius))) - dy * 0.005;
    phi = Math.max(0.1, Math.min(Math.PI - 0.1, phi));
    camera.position.x = radius * Math.sin(phi) * Math.sin(theta);
    camera.position.y = radius * Math.cos(phi);
    camera.position.z = radius * Math.sin(phi) * Math.cos(theta);
    camera.lookAt(0, 0, 0);
    prevMouse = {x: e.clientX, y: e.clientY};
  });
  canvas.addEventListener('mouseup', function() { isDragging = false; });
  canvas.addEventListener('wheel', function(e) {
    e.preventDefault();
    camera.position.multiplyScalar(e.deltaY > 0 ? 1.1 : 0.9);
  });
  window.addEventListener('resize', onResize);
}

function addBases() {
  bases.forEach(function(b) {
    var pos = latLonTo3D(b.lat, b.lon, 0);
    var size = b.is_ace_hub ? 30 : 15;
    var geo = new THREE.ConeGeometry(size, size * 2, 8);
    var mat = new THREE.MeshPhongMaterial({
      color: b.is_ace_hub ? 0x00ff88 : 0x4e9af5,
      emissive: b.is_ace_hub ? 0x004422 : 0x001122
    });
    var mesh = new THREE.Mesh(geo, mat);
    mesh.position.copy(pos);
    mesh.lookAt(0, 0, 0);
    mesh.rotateX(Math.PI / 2);
    scene.add(mesh);
  });
}

function addAircraft() {
  aircraft.forEach(function(e) {
    var pos = latLonTo3D(e.lat, e.lon, e.alt_m || 10000);
    var color = e.affiliation === 'hostile' ? 0xff4444 : 0x4e9af5;
    var geo = new THREE.BoxGeometry(12, 4, 12);
    var mat = new THREE.MeshPhongMaterial({ color: color, emissive: 0x001133 });
    var mesh = new THREE.Mesh(geo, mat);
    mesh.position.copy(pos);
    scene.add(mesh);
    entityMeshes[e.id] = mesh;
    // Glow
    var glow = new THREE.Mesh(
      new THREE.SphereGeometry(15, 8, 8),
      new THREE.MeshBasicMaterial({ color: color, transparent: true, opacity: 0.2 })
    );
    glow.position.copy(pos);
    scene.add(glow);
  });
}

function addMissiles() {
  missiles.forEach(function(e) {
    var pos = latLonTo3D(e.lat, e.lon, e.alt_m || 50000);
    var geo = new THREE.ConeGeometry(8, 20, 6);
    var mat = new THREE.MeshPhongMaterial({ color: 0xff4444, emissive: 0x440000 });
    var mesh = new THREE.Mesh(geo, mat);
    mesh.position.copy(pos);
    scene.add(mesh);
    entityMeshes[e.id] = mesh;
  });
}

function addSensorDomes() {
  layerGroups.sensors = new THREE.Group();
  sensors.forEach(function(s) {
    var pos = latLonTo3D(s.lat, s.lon, 0);
    var range = (s.detection_range_km || 300) * 0.8;
    // Hemisphere for sensor coverage
    var geo = new THREE.SphereGeometry(range, 24, 16, 0, Math.PI * 2, 0, Math.PI / 2);
    var mat = new THREE.MeshBasicMaterial({
      color: 0x4ef59e, transparent: true, opacity: 0.08,
      side: THREE.DoubleSide, depthWrite: false
    });
    var dome = new THREE.Mesh(geo, mat);
    dome.position.copy(pos);
    dome.lookAt(0, 0, 0);
    dome.rotateX(Math.PI);
    layerGroups.sensors.add(dome);
    // Wireframe outline
    var wire = new THREE.Mesh(
      new THREE.SphereGeometry(range, 16, 8, 0, Math.PI * 2, 0, Math.PI / 2),
      new THREE.MeshBasicMaterial({ color: 0x4ef59e, wireframe: true, transparent: true, opacity: 0.15 })
    );
    wire.position.copy(pos);
    wire.lookAt(0, 0, 0);
    wire.rotateX(Math.PI);
    layerGroups.sensors.add(wire);
  });
  scene.add(layerGroups.sensors);
}

function addEWZones() {
  layerGroups.ew = new THREE.Group();
  ewThreats.forEach(function(e) {
    var pos = latLonTo3D(
      e.lat || e.target_lat || 0,
      e.lon || e.target_lon || 0,
      e.alt_m || 15000
    );
    var range = (e.jam_range_km || 200) * 0.8;
    var eff = e.effectiveness || 0.5;
    var geo = new THREE.SphereGeometry(range, 20, 12);
    var mat = new THREE.MeshBasicMaterial({
      color: 0xf5a04e, transparent: true, opacity: 0.06 + eff * 0.1,
      side: THREE.DoubleSide, depthWrite: false
    });
    var sphere = new THREE.Mesh(geo, mat);
    sphere.position.copy(pos);
    layerGroups.ew.add(sphere);
    // Pulsing wireframe
    var wire = new THREE.Mesh(
      new THREE.SphereGeometry(range, 12, 8),
      new THREE.MeshBasicMaterial({ color: 0xf5a04e, wireframe: true, transparent: true, opacity: 0.2 })
    );
    wire.position.copy(pos);
    wire.userData.isEW = true;
    layerGroups.ew.add(wire);
  });
  scene.add(layerGroups.ew);
}

function addCyberZones() {
  layerGroups.cyber = new THREE.Group();
  cyberThreats.forEach(function(e) {
    var pos = latLonTo3D(
      e.lat || e.target_lat || 0,
      e.lon || e.target_lon || 0,
      e.alt_m || 8000
    );
    var phaseColors = {
      infiltration: 0xa04ef5, persistence: 0xc24ef5,
      impact: 0xff00ff, remediated: 0x4ef5d4
    };
    var color = phaseColors[e.phase] || 0xa04ef5;
    var range = 150;
    var geo = new THREE.TorusGeometry(range, 15, 8, 24);
    var mat = new THREE.MeshBasicMaterial({ color: color, transparent: true, opacity: 0.3 });
    var ring = new THREE.Mesh(geo, mat);
    ring.position.copy(pos);
    ring.lookAt(0, 0, 0);
    layerGroups.cyber.add(ring);
    // Inner sphere
    var innerGeo = new THREE.SphereGeometry(range * 0.5, 12, 8);
    var innerMat = new THREE.MeshBasicMaterial({ color: color, transparent: true, opacity: 0.08 });
    var inner = new THREE.Mesh(innerGeo, innerMat);
    inner.position.copy(pos);
    layerGroups.cyber.add(inner);
  });
  scene.add(layerGroups.cyber);
}

function addKalmanTracks() {
  layerGroups.kalman = new THREE.Group();
  kalmanTracks.forEach(function(t) {
    var pos = latLonTo3D(t.lat, t.lon, t.alt_m || t.alt || 5000);
    var conf = t.confidence || 0.5;
    var color = confidenceColor(conf);
    var size = 4 + conf * 8;
    var geo = new THREE.SphereGeometry(size, 10, 8);
    var mat = new THREE.MeshBasicMaterial({
      color: color, transparent: true, opacity: 0.4 + conf * 0.4
    });
    var mesh = new THREE.Mesh(geo, mat);
    mesh.position.copy(pos);
    layerGroups.kalman.add(mesh);
    // Velocity vector line
    if (t.v_lat || t.v_lon) {
      var vMag = Math.sqrt((t.v_lat||0)**2 + (t.v_lon||0)**2);
      if (vMag > 0.01) {
        var endPos = latLonTo3D(
          t.lat + (t.v_lat || 0) * 10,
          t.lon + (t.v_lon || 0) * 10,
          t.alt_m || 5000
        );
        var lineGeo = new THREE.BufferGeometry().setFromPoints([pos, endPos]);
        var lineMat = new THREE.LineBasicMaterial({ color: color, transparent: true, opacity: 0.5 });
        layerGroups.kalman.add(new THREE.Line(lineGeo, lineMat));
      }
    }
    // Confidence ring
    var ringGeo = new THREE.RingGeometry(size + 2, size + 4, 16);
    var ringMat = new THREE.MeshBasicMaterial({ color: color, transparent: true, opacity: 0.5, side: THREE.DoubleSide });
    var ring = new THREE.Mesh(ringGeo, ringMat);
    ring.position.copy(pos);
    ring.lookAt(0, 0, 0);
    layerGroups.kalman.add(ring);
  });
  scene.add(layerGroups.kalman);
}

function addTrajectories() {
  layerGroups.trajectory = new THREE.Group();
  missiles.forEach(function(m) {
    var startPos = latLonTo3D(m.lat, m.lon, m.alt_m || 50000);
    var targetLat = m.target_lat || m.lat + 5;
    var targetLon = m.target_lon || m.lon + 5;
    var targetPos = latLonTo3D(targetLat, targetLon, 0);
    // Animated arc trajectory
    var midPoint = new THREE.Vector3(
      (startPos.x + targetPos.x) / 2,
      (startPos.y + targetPos.y) / 2 + 300,
      (startPos.z + targetPos.z) / 2
    );
    var curve = new THREE.QuadraticBezierCurve3(startPos, midPoint, targetPos);
    var points = curve.getPoints(40);
    var geo = new THREE.BufferGeometry().setFromPoints(points);
    var mat = new THREE.LineBasicMaterial({ color: 0xff4444, transparent: true, opacity: 0.35 });
    var line = new THREE.Line(geo, mat);
    line.userData.curve = curve;
    line.userData.isTrajectory = true;
    layerGroups.trajectory.add(line);

    // Moving marker on trajectory
    var markerGeo = new THREE.SphereGeometry(5, 8, 6);
    var markerMat = new THREE.MeshBasicMaterial({ color: 0xff8888, transparent: true, opacity: 0.8 });
    var marker = new THREE.Mesh(markerGeo, markerMat);
    marker.userData.curve = curve;
    marker.userData.isMarker = true;
    marker.userData.phase = Math.random();
    layerGroups.trajectory.add(marker);
  });
  scene.add(layerGroups.trajectory);
}

function addWeatherOverlay() {
  layerGroups.weather = new THREE.Group();
  var detFactor = weather.detection_range_factor || 1.0;
  var visFactor = weather.visibility_factor || 1.0;
  if (detFactor < 0.9 || visFactor < 0.9) {
    // Weather degradation: add cloud layer
    var cloudGeo = new THREE.SphereGeometry(6380, 32, 16);
    var cloudMat = new THREE.MeshBasicMaterial({
      color: 0x4a5a6a, transparent: true,
      opacity: (1.0 - detFactor) * 0.3
    });
    var cloud = new THREE.Mesh(cloudGeo, cloudMat);
    layerGroups.weather.add(cloud);
    // Rain particles (simple dots)
    if (visFactor < 0.7) {
      var rainGeo = new THREE.BufferGeometry();
      var rainPositions = [];
      for (var i = 0; i < 200; i++) {
        var lat = (Math.random() - 0.5) * 60;
        var lon = (Math.random() - 0.5) * 120;
        var alt = Math.random() * 50 + 6371;
        var p = latLonTo3D(lat, lon, alt * 1000);
        rainPositions.push(p.x, p.y, p.z);
      }
      rainGeo.setAttribute('position', new THREE.Float32BufferAttribute(rainPositions, 3));
      var rainMat = new THREE.PointsMaterial({ color: 0x6a9aba, size: 3, transparent: true, opacity: 0.6 });
      layerGroups.weather.add(new THREE.Points(rainGeo, rainMat));
    }
  }
  scene.add(layerGroups.weather);
}

function animate() {
  requestAnimationFrame(animate);
  animTime += 0.016;

  // Rotate entity meshes
  Object.keys(entityMeshes).forEach(function(id) {
    if (entityMeshes[id]) entityMeshes[id].rotation.y += 0.02;
  });

  // Animate missile trajectory markers
  if (layerGroups.trajectory) {
    layerGroups.trajectory.children.forEach(function(child) {
      if (child.userData.isMarker && child.userData.curve) {
        child.userData.phase = (child.userData.phase + 0.005) % 1.0;
        var p = child.userData.curve.getPoint(child.userData.phase);
        child.position.copy(p);
      }
    });
  }

  // Pulse EW zones
  if (layerGroups.ew) {
    layerGroups.ew.children.forEach(function(child) {
      if (child.userData.isEW) {
        var pulse = 0.15 + Math.sin(animTime * 2) * 0.05;
        child.material.opacity = pulse;
      }
    });
  }

  // Pulse cyber rings
  if (layerGroups.cyber) {
    layerGroups.cyber.children.forEach(function(child, i) {
      if (child.geometry && child.geometry.type === 'TorusGeometry') {
        child.rotation.z += 0.01;
        var s = 1 + Math.sin(animTime * 3 + i) * 0.1;
        child.scale.set(s, s, s);
      }
    });
  }

  renderer.render(scene, camera);
}

function onResize() {
  camera.aspect = window.innerWidth / (window.innerHeight - 50);
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight - 50);
}

init();
</script>
</body>
</html>"""
