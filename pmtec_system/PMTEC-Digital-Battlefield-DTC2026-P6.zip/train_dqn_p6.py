#!/usr/bin/env python3
"""
P6 DQN Curriculum Training - 200K steps with 3-phase difficulty.

P6-1 env changes: 182-dim observation, dynamic intercept probability,
reward shaping (intercept +5, loss -2, strategy-match bonus).

P6-3 curriculum: easy 50K -> medium 100K -> hard 50K (total 200K).
Hyperparams: lr=5e-4, eps=1.0->0.02, exploration_fraction=0.3,
batch_size=64, target_update_interval=250.

Usage: python train_dqn_p6.py
"""

import sys
import os
import time
import json
import numpy as np

PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

os.environ["PMTEC_HEADLESS"] = "1"

from stable_baselines3 import DQN
from stable_baselines3.common.vec_env import DummyVecEnv
from stable_baselines3.common.callbacks import CheckpointCallback, BaseCallback
import torch
import torch.nn as nn

from deep_rl.pmtec_env import PMTECEnv, OBS_DIM
from deep_rl.dqn_agent import detect_best_device

_MODEL_DIR = os.path.join(PROJECT_ROOT, "data", "models")
FINAL_MODEL = os.path.join(_MODEL_DIR, "pmtec_dqn_p6.zip")
HISTORY_PATH = os.path.join(_MODEL_DIR, "pmtec_dqn_p6_history.json")


class CurriculumCallback(BaseCallback):
    """Switch env difficulty at phase boundaries and log metrics.

    Phase 1 (0-50K):    easy   - fewer threats, mostly cruise, no EW/cyber
    Phase 2 (50K-150K): medium - default difficulty, all threat types
    Phase 3 (150K-200K): hard  - more threats, more hypersonic, frequent EW/cyber
    """

    PHASES = [
        (0, 50000, "easy"),
        (50000, 150000, "medium"),
        (150000, 200000, "hard"),
    ]

    def __init__(self, log_interval=100):
        super().__init__(verbose=1)
        self.log_interval = log_interval
        self.episode_rewards = []
        self.episode_intercept_rates = []
        self.current_phase = "easy"

    def _on_training_start(self):
        print(f"[Curriculum] Phase 1: easy (0-50K steps)")

    def _on_step(self):
        ts = self.num_timesteps

        # Check phase transitions
        for start, end, difficulty in self.PHASES:
            if ts >= start and ts < end and self.current_phase != difficulty:
                self.current_phase = difficulty
                # Switch difficulty on the underlying env
                try:
                    inner_env = self.training_env.envs[0]
                    if hasattr(inner_env, "difficulty"):
                        inner_env.difficulty = difficulty
                    print(
                        f"\n[Curriculum] Phase transition at step {ts}: -> {difficulty}\n"
                    )
                except Exception:
                    pass

        # Log intercept rates
        infos = self.locals.get("infos", [])
        for info in infos:
            if "intercept_rate" in info:
                self.episode_intercept_rates.append(info["intercept_rate"])
                if len(self.episode_intercept_rates) % self.log_interval == 0:
                    recent = self.episode_intercept_rates[-self.log_interval :]
                    avg_ir = np.mean(recent) if recent else 0
                    print(
                        f"  [Step {ts:>7d}] Phase={self.current_phase} "
                        f"| Episodes: {len(self.episode_intercept_rates)} "
                        f"| Recent avg intercept_rate: {avg_ir:.1%}",
                        flush=True,
                    )
        return True


def main():
    device = detect_best_device()
    print("=" * 70)
    print("PMTEC DQN P6 Curriculum Training (200K steps, 182-dim)")
    print(f"Device: {device}")
    if "xpu" in device:
        print(f"  GPU: {torch.xpu.get_device_name(0)}")
        mem = torch.xpu.get_device_properties(0).total_memory / 1e9
        print(f"  Memory: {mem:.2f} GB")
    print(f"  Observation dim: {OBS_DIM}")
    print(f"  Curriculum: easy(50K) -> medium(100K) -> hard(50K)")
    print(f"  Hyperparams: lr=5e-4, eps=1.0->0.02, exploration_frac=0.3,")
    print(f"                batch=64, target_update=250, buffer=50000")
    print(f"  Final model: {FINAL_MODEL}")
    print("=" * 70)

    # Create environment starting with easy difficulty
    env = PMTECEnv(duration=120, seed=42)
    env.difficulty = "easy"
    vec_env = DummyVecEnv([lambda: env])
    print(
        f"Environment: PMTECEnv | obs_dim={env.observation_space.shape[0]} "
        f"| actions={env.action_space.n} | difficulty={env.difficulty}"
    )
    print()

    # P6-3 optimized hyperparameters
    policy_kwargs = {
        "net_arch": [128, 64],
        "activation_fn": nn.ReLU,
    }

    model = DQN(
        "MlpPolicy",
        vec_env,
        learning_rate=5e-4,
        buffer_size=50000,
        batch_size=64,
        gamma=0.95,
        exploration_fraction=0.3,
        exploration_initial_eps=1.0,
        exploration_final_eps=0.02,
        target_update_interval=250,
        train_freq=4,
        policy_kwargs=policy_kwargs,
        device=device,
        verbose=1,
    )

    # Checkpoint callback - saves every 50K steps
    checkpoint_cb = CheckpointCallback(
        save_freq=50000,
        save_path=_MODEL_DIR,
        name_prefix="pmtec_dqn_p6_checkpoint",
        save_replay_buffer=False,
        save_vecnormalize=False,
    )

    # Curriculum + reward logger
    curriculum_cb = CurriculumCallback(log_interval=100)

    # Train 200K steps with curriculum
    print("Starting curriculum training (200K steps)...")
    t0 = time.time()
    model.learn(
        total_timesteps=200000,
        callback=[checkpoint_cb, curriculum_cb],
        reset_num_timesteps=True,
        progress_bar=False,
    )
    elapsed = time.time() - t0

    # Save final model
    model.save(FINAL_MODEL)
    print(f"\nFinal model saved to: {FINAL_MODEL}")
    print(f"Training elapsed: {elapsed:.1f}s ({elapsed / 60:.1f} min)")

    # Evaluation: run 10 episodes on medium difficulty
    print("\n" + "=" * 70)
    print("Evaluation (10 episodes, medium difficulty, deterministic)")
    print("=" * 70)
    eval_env = PMTECEnv(duration=120, seed=999)
    eval_env.difficulty = "medium"
    eval_results = []
    for ep in range(10):
        obs, _ = eval_env.reset(seed=200 + ep)
        total_reward = 0.0
        done = False
        info = {}
        while not done:
            action, _ = model.predict(obs, deterministic=True)
            if hasattr(action, "item"):
                action = action.item()
            elif hasattr(action, "__len__"):
                action = int(action.flat[0])
            obs, reward, done, _, info = eval_env.step(action)
            total_reward += reward
        ir = info.get("intercept_rate", 0)
        eval_results.append(
            {
                "episode": ep,
                "total_reward": round(total_reward, 2),
                "intercept_rate": round(ir, 4),
                "aircraft_survived": info.get("active_aircraft", 0),
                "missiles_intercepted": info.get("intercepted_missiles", 0),
                "active_missiles": info.get("active_missiles", 0),
            }
        )
        print(
            f"  Ep {ep}: reward={total_reward:.1f}, intercept_rate={ir:.1%}, "
            f"intercepted={info.get('intercepted_missiles', 0)}"
        )

    avg_reward = np.mean([r["total_reward"] for r in eval_results])
    avg_ir = np.mean([r["intercept_rate"] for r in eval_results])
    max_ir = np.max([r["intercept_rate"] for r in eval_results])
    print(f"\n  AVG: reward={avg_reward:.1f}, intercept_rate={avg_ir:.1%}")
    print(f"  MAX: intercept_rate={max_ir:.1%}")

    # Save history
    history = {
        "version": "P6",
        "obs_dim": OBS_DIM,
        "total_timesteps": 200000,
        "curriculum": [
            {"phase": "easy", "start": 0, "end": 50000, "steps": 50000},
            {"phase": "medium", "start": 50000, "end": 150000, "steps": 100000},
            {"phase": "hard", "start": 150000, "end": 200000, "steps": 50000},
        ],
        "hyperparams": {
            "learning_rate": 5e-4,
            "buffer_size": 50000,
            "batch_size": 64,
            "gamma": 0.95,
            "exploration_fraction": 0.3,
            "exploration_initial_eps": 1.0,
            "exploration_final_eps": 0.02,
            "target_update_interval": 250,
            "train_freq": 4,
            "net_arch": [128, 64],
        },
        "elapsed_seconds": round(elapsed, 1),
        "device": device,
        "final_avg_reward": round(avg_reward, 2),
        "final_avg_intercept_rate": round(avg_ir, 4),
        "final_max_intercept_rate": round(max_ir, 4),
        "eval_results": eval_results,
        "saved_model": FINAL_MODEL,
    }
    with open(HISTORY_PATH, "w", encoding="utf-8") as f:
        json.dump(history, f, indent=2, ensure_ascii=False)
    print(f"\nHistory saved to: {HISTORY_PATH}")
    print("=" * 70)
    print("DQN P6 curriculum training complete!")
    print(f"  Total steps: 200000 (50K easy + 100K medium + 50K hard)")
    print(f"  Final model: {FINAL_MODEL}")
    print(f"  Avg reward: {avg_reward:.1f}")
    print(f"  Avg intercept rate: {avg_ir:.1%}")
    print(f"  Max intercept rate: {max_ir:.1%}")
    print("=" * 70)


if __name__ == "__main__":
    main()
