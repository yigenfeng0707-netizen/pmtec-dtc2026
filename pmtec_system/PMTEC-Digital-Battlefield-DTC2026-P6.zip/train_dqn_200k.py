#!/usr/bin/env python3
"""
DQN 200K Training - Continue from existing 50K model with checkpoint saving.

Loads pmtec_dqn.zip (50K steps from P3-3), continues training for 150K more
steps (total 200K effective), saves checkpoints every 25K steps.

Usage: python train_dqn_200k.py
"""

import sys
import os
import time
import json
import numpy as np

PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

os.environ["PMTEC_HEADLESS"] = "1"

from stable_baselines3 import DQN
from stable_baselines3.common.vec_env import DummyVecEnv
from stable_baselines3.common.callbacks import CheckpointCallback, BaseCallback
import torch
import torch.nn as nn

from deep_rl.pmtec_env import PMTECEnv
from deep_rl.dqn_agent import detect_best_device

_MODEL_DIR = os.path.join(PROJECT_ROOT, "data", "models")
_EXISTING_MODEL = os.path.join(_MODEL_DIR, "pmtec_dqn.zip")
FINAL_MODEL = os.path.join(_MODEL_DIR, "pmtec_dqn_200k.zip")
HISTORY_PATH = os.path.join(_MODEL_DIR, "pmtec_dqn_200k_history.json")


class RewardLogger(BaseCallback):
    """Log episode rewards and intercept rates during training."""

    def __init__(self, log_interval=50):
        super().__init__(verbose=1)
        self.log_interval = log_interval
        self.episode_rewards = []
        self.episode_intercept_rates = []

    def _on_step(self):
        infos = self.locals.get("infos", [])
        for info in infos:
            if "episode" in self.locals.get("infos", [{}])[0]:
                pass
            if "intercept_rate" in info:
                self.episode_intercept_rates.append(info["intercept_rate"])
                if len(self.episode_intercept_rates) % self.log_interval == 0:
                    recent = self.episode_intercept_rates[-self.log_interval :]
                    avg_ir = np.mean(recent) if recent else 0
                    ts = self.num_timesteps
                    print(
                        f"  [Step {ts:>7d}] Episodes: {len(self.episode_intercept_rates)} "
                        f"| Recent avg intercept_rate: {avg_ir:.1%}",
                        flush=True,
                    )
        return True


def main():
    device = detect_best_device()
    print("=" * 70)
    print("PMTEC DQN 200K Training - Continue from 50K model")
    print(f"Device: {device}")
    if "xpu" in device:
        print(f"  GPU: {torch.xpu.get_device_name(0)}")
        mem = torch.xpu.get_device_properties(0).total_memory / 1e9
        print(f"  Memory: {mem:.2f} GB")
    print(f"  Existing model: {_EXISTING_MODEL}")
    print(f"  Exists: {os.path.exists(_EXISTING_MODEL)}")
    print(f"  Continue timesteps: 150000 (total effective: 200000)")
    print(f"  Checkpoint interval: 25000 steps")
    print("=" * 70)

    # Create environment
    env = PMTECEnv(duration=120, seed=42)
    vec_env = DummyVecEnv([lambda: env])
    print(
        f"Environment: PMTECEnv | obs_dim={env.observation_space.shape[0]} | actions={env.action_space.n}"
    )
    print()

    # Load existing 50K model
    print("Loading existing 50K DQN model...")
    model = DQN.load(
        _EXISTING_MODEL,
        env=vec_env,
        device=device,
        custom_objects={
            "learning_rate": 5e-5,  # Lower LR for fine-tuning
            "exploration_initial_eps": 0.3,  # Start with some exploration
            "exploration_final_eps": 0.02,
            "exploration_fraction": 0.2,  # 20% of new steps for exploration decay
        },
    )
    print(f"Model loaded. Continuing training for 150000 more steps...")
    print(f"  Current exploration eps: {model.exploration_rate:.4f}")
    print()

    # Checkpoint callback - saves every 25K steps
    checkpoint_cb = CheckpointCallback(
        save_freq=25000,
        save_path=_MODEL_DIR,
        name_prefix="pmtec_dqn_200k_checkpoint",
        save_replay_buffer=False,
        save_vecnormalize=False,
    )

    # Reward logger
    reward_logger = RewardLogger(log_interval=50)

    # Continue training
    t0 = time.time()
    model.learn(
        total_timesteps=150000,
        callback=[checkpoint_cb, reward_logger],
        reset_num_timesteps=False,
        progress_bar=False,
    )
    elapsed = time.time() - t0

    # Save final model
    model.save(FINAL_MODEL)
    print(f"\nFinal model saved to: {FINAL_MODEL}")
    print(f"Training elapsed: {elapsed:.1f}s ({elapsed / 60:.1f} min)")

    # Evaluation
    print("\nEvaluating trained agent (5 episodes, deterministic)...")
    eval_results = []
    for ep in range(5):
        obs, _ = env.reset(seed=100 + ep)
        total_reward = 0.0
        done = False
        info = {}
        while not done:
            action, _ = model.predict(obs, deterministic=True)
            if hasattr(action, "item"):
                action = action.item()
            elif hasattr(action, "__len__"):
                action = int(action.flat[0])
            obs, reward, done, _, info = env.step(action)
            total_reward += reward
        eval_results.append(
            {
                "episode": ep,
                "total_reward": round(total_reward, 2),
                "intercept_rate": round(info.get("intercept_rate", 0), 3),
                "aircraft_survived": info.get("active_aircraft", 0),
                "missiles_intercepted": info.get("intercepted_missiles", 0),
            }
        )
        print(
            f"  Ep {ep}: reward={total_reward:.1f}, intercept_rate={info.get('intercept_rate', 0):.1%}"
        )

    avg_reward = np.mean([r["total_reward"] for r in eval_results])
    avg_ir = np.mean([r["intercept_rate"] for r in eval_results])
    print(f"\n  AVG: reward={avg_reward:.1f}, intercept_rate={avg_ir:.1%}")

    # Save history
    history = {
        "base_model": "pmtec_dqn.zip (50K steps)",
        "continue_timesteps": 150000,
        "total_effective_timesteps": 200000,
        "elapsed_seconds": round(elapsed, 1),
        "device": device,
        "learning_rate": 5e-5,
        "final_avg_reward": round(avg_reward, 2),
        "final_avg_intercept_rate": round(avg_ir, 4),
        "eval_results": eval_results,
        "saved_model": FINAL_MODEL,
    }
    with open(HISTORY_PATH, "w", encoding="utf-8") as f:
        json.dump(history, f, indent=2, ensure_ascii=False)
    print(f"\nHistory saved to: {HISTORY_PATH}")
    print("=" * 70)
    print("DQN 200K training complete!")
    print(f"  Total effective steps: 200000 (50K base + 150K continue)")
    print(f"  Final model: {FINAL_MODEL}")
    print(f"  Avg reward: {avg_reward:.1f}")
    print(f"  Avg intercept rate: {avg_ir:.1%}")
    print("=" * 70)


if __name__ == "__main__":
    main()
