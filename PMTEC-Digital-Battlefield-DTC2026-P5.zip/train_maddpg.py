#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
P5-2: Train MADDPG (Multi-Agent DDPG) for PMTEC.

Replaces IQL with centralized-training decentralized-execution:
  - Each agent has Actor (local obs -> action) + Critic (all obs + all actions -> Q)
  - Soft target updates (tau=0.005)
  - Gumbel-Softmax for differentiable discrete actions

Usage: python train_maddpg.py [timesteps]
Default: 8000 timesteps (initial training, P5-3 extends to 200K)
"""

import os
import sys
import time
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
os.environ["PMTEC_HEADLESS"] = "1"

from deep_rl.maddpg_agent import MADDPGAgent
from deep_rl.multi_agent_env import MultiAgentPMTECEnv


def evaluate(trainer: MADDPGAgent, n_episodes: int = 5):
    """Run evaluation episodes with deterministic policies."""
    print("\n[Evaluation] Running %d episodes..." % n_episodes)
    ma_env = MultiAgentPMTECEnv(duration=120, seed=999)
    rewards = []
    intercept_rates = []

    for ep in range(n_episodes):
        obs_dict, _ = ma_env.reset(seed=999 + ep)
        ep_reward = 0
        done = False
        truncated = False
        steps = 0

        while not (done or truncated) and steps < 500:
            obs = obs_dict["intercept"]
            actions = trainer.predict(obs)
            obs_dict, reward, done, truncated, info = ma_env.step(actions)
            ep_reward += reward
            steps += 1

        inner = ma_env.get_inner_env()
        ir = (
            getattr(inner, "intercept_rate", 0.0)
            if hasattr(inner, "intercept_rate")
            else 0.0
        )
        rewards.append(ep_reward)
        intercept_rates.append(ir)
        print(f"  Episode {ep + 1}: reward={ep_reward:.1f}, intercept_rate={ir:.2f}%")

    avg_r = np.mean(rewards)
    avg_ir = np.mean(intercept_rates)
    print(f"\n  Average reward: {avg_r:.1f}")
    print(f"  Average intercept rate: {avg_ir:.2f}%")
    return avg_r, avg_ir


if __name__ == "__main__":
    timesteps = int(sys.argv[1]) if len(sys.argv) > 1 else 8000

    print("=" * 60)
    print("P5-2: MADDPG Training")
    print("=" * 60)

    trainer = MADDPGAgent(
        lr_actor=1e-4,
        lr_critic=1e-3,
        gamma=0.95,
        tau=0.005,
        buffer_size=50000,
        batch_size=128,
        epsilon_start=0.9,
        epsilon_end=0.05,
        epsilon_decay=0.9995,
        device="auto",
    )

    ma_env = MultiAgentPMTECEnv(duration=120, seed=42)

    entry = trainer.train(total_timesteps=timesteps, ma_env=ma_env)

    # Evaluation
    evaluate(trainer, n_episodes=5)

    print("\n" + "=" * 60)
    print("Training Complete!")
    print(f"  Algorithm: MADDPG (Multi-Agent DDPG)")
    print(f"  Total timesteps: {timesteps}")
    print(f"  Elapsed: {entry['elapsed_seconds']}s")
    print(f"  Device: {entry['device']}")
    print(f"  Hidden actor: {entry['hidden_actor']}")
    print(f"  Hidden critic: {entry['hidden_critic']}")
    print(f"  Intercept model: {trainer.intercept_model_path}")
    print(f"  Dispersal model: {trainer.dispersal_model_path}")
    print("=" * 60)
