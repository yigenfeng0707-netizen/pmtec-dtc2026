#!/usr/bin/env python3
"""Quick validation: PMTECEnv produces 122-dim observation with EW/Cyber/Weather features."""

import sys, os

PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

import numpy as np
from deep_rl.pmtec_env import PMTECEnv, OBS_DIM


def main():
    print(f"Expected OBS_DIM = {OBS_DIM}")
    env = PMTECEnv(duration=120, seed=42)
    print(f"Env observation_space shape = {env.observation_space.shape}")
    print(f"Env action_space = {env.action_space}")
    assert env.observation_space.shape[0] == 122, (
        f"Expected 122, got {env.observation_space.shape[0]}"
    )

    obs, info = env.reset(seed=42)
    print(f"Reset obs shape = {obs.shape}, dtype = {obs.dtype}")
    print(f"Reset info keys = {list(info.keys())}")
    print(f"  obs_dim = {info.get('obs_dim')}")
    print(f"  weather = {info.get('weather')}")
    print(f"  active_ew_threats = {info.get('active_ew_threats')}")
    print(f"  active_cyber_threats = {info.get('active_cyber_threats')}")

    # Check value ranges
    print(f"  obs min = {obs.min():.4f}, max = {obs.max():.4f}")
    print(f"  obs[0:5] = {obs[0:5]}  (base 0 features)")
    print(f"  obs[110:122] = {obs[110:122]}  (global features incl EW/Cyber/Weather)")

    # Run a few steps
    total_reward = 0
    for step in range(5):
        action = env.action_space.sample()
        obs, reward, done, truncated, info = env.step(action)
        total_reward += reward
        ew = info.get("active_ew_threats", 0)
        cyb = info.get("active_cyber_threats", 0)
        wx = info.get("weather", {})
        print(
            f"  Step {step}: reward={reward:.2f}, ew={ew}, cyber={cyb}, "
            f"wx_det={wx.get('detection_range_factor', 0):.2f}, "
            f"obs[110:122]={obs[110:122]}"
        )
        if done:
            break

    print(f"\nTotal reward over 5 steps: {total_reward:.2f}")
    print(f"Final obs[4] (ew_jammed base 0): {obs[4]:.3f}")
    print(f"Final global obs[6] (ew_count): {obs[6]:.3f}")
    print(f"Final global obs[7] (cyber_phase): {obs[7]:.3f}")
    print(f"Final global obs[9] (wx_det): {obs[9]:.3f}")
    print("\n=== VALIDATION PASSED: 122-dim obs with EW/Cyber/Weather ===")
    os._exit(0)


if __name__ == "__main__":
    main()
