#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Train Multi-Agent IQL for PMTEC (P4-4).

Independent Q-Learning with two cooperative agents:
  - Intercept Agent: 3 actions (direct, predictive, saturation)
  - Dispersal Agent: 3 actions (hold, light 15%, heavy 30%)

Usage: python train_multi_agent.py [timesteps]
Default: 6000 timesteps (2000 per round x 3 rounds)
"""

import sys
import os
import time

PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

os.environ["PMTEC_HEADLESS"] = "1"

from deep_rl.multi_agent_env import MultiAgentPMTECEnv
from deep_rl.multi_agent_dqn import MultiAgentDQN


def main():
    timesteps = int(sys.argv[1]) if len(sys.argv) > 1 else 6000

    print("=" * 60)
    print(f"PMTEC Multi-Agent IQL Training (P4-4)")
    print(f"Timesteps: {timesteps} (3 rounds, {timesteps // 3} per agent per round)")
    print("=" * 60)

    # Create multi-agent environment
    ma_env = MultiAgentPMTECEnv(duration=120, seed=42)
    print(f"Environment: MultiAgentPMTECEnv")
    print(f"  Intercept agent: 3 actions (direct, predictive, saturation)")
    print(f"  Dispersal agent: 3 actions (hold, light 15%, heavy 30%)")
    print(f"  Observation: 122-dim shared state")
    print()

    # Create multi-agent DQN trainer
    trainer = MultiAgentDQN(
        learning_rate=1e-4,
        buffer_size=20000,
        batch_size=64,
        gamma=0.95,
        exploration_fraction=0.3,
        exploration_final_eps=0.05,
    )

    t0 = time.time()
    result = trainer.train(total_timesteps=timesteps, ma_env=ma_env)
    elapsed = time.time() - t0

    print()
    print("=" * 60)
    print(f"Training Complete!")
    print(f"  Algorithm: IQL (Independent Q-Learning)")
    print(f"  Total timesteps: {result['timesteps']}")
    print(
        f"  Elapsed: {elapsed:.1f}s ({result.get('elapsed_seconds', 0):.1f}s reported)"
    )
    print(f"  Device: {result['device']}")
    print(f"  Network: {result['net_arch']}")
    print(f"  Intercept model: {trainer.intercept_model_path}")
    print(f"  Dispersal model: {trainer.dispersal_model_path}")
    print("=" * 60)

    # Quick evaluation
    print("\n[Evaluation] Running 5 episodes...")
    eval_rewards = []
    eval_intercepts = []
    for ep in range(5):
        obs_dict, _ = ma_env.reset(seed=42 + ep)
        ep_reward = 0
        done = False
        while not done:
            actions = trainer.predict(obs_dict["intercept"])
            obs_dict, reward, done, _, info = ma_env.step(actions)
            ep_reward += reward
        inner_info = info.get("intercept", {})
        ir = inner_info.get("intercept_rate", 0)
        eval_rewards.append(ep_reward)
        eval_intercepts.append(ir)
        print(f"  Episode {ep + 1}: reward={ep_reward:.1f}, intercept_rate={ir:.2%}")

    avg_r = sum(eval_rewards) / len(eval_rewards)
    avg_ir = sum(eval_intercepts) / len(eval_intercepts)
    print(f"\n  Average reward: {avg_r:.1f}")
    print(f"  Average intercept rate: {avg_ir:.2%}")

    return 0


if __name__ == "__main__":
    sys.exit(main())
