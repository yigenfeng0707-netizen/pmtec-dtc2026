#!/usr/bin/env python3
"""
DQN 200K Training - Fresh model with correct timestep management.

Creates a new DQN model, trains for 200K timesteps with minimal logging
for maximum speed. Saves checkpoints every 50K and final model.

Usage: python train_dqn_200k_v2.py
"""

import sys
import os
import time
import json
import numpy as np

PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

os.environ["PMTEC_HEADLESS"] = "1"

from stable_baselines3 import DQN
from stable_baselines3.common.vec_env import DummyVecEnv
from stable_baselines3.common.callbacks import CheckpointCallback, BaseCallback
import torch
import torch.nn as nn

from deep_rl.pmtec_env import PMTECEnv
from deep_rl.dqn_agent import detect_best_device

_MODEL_DIR = os.path.join(PROJECT_ROOT, "data", "models")
FINAL_MODEL = os.path.join(_MODEL_DIR, "pmtec_dqn_200k.zip")
HISTORY_PATH = os.path.join(_MODEL_DIR, "pmtec_dqn_200k_history.json")


class ProgressCallback(BaseCallback):
    """Minimal progress logger - only log every 10K steps to avoid I/O overhead."""

    def __init__(self):
        super().__init__(verbose=0)
        self.rewards = []
        self.intercept_rates = []

    def _on_step(self):
        infos = self.locals.get("infos", [])
        for info in infos:
            if "intercept_rate" in info:
                self.intercept_rates.append(info["intercept_rate"])
        # Log every 10000 steps
        if self.num_timesteps % 10000 == 0 and self.num_timesteps > 0:
            recent = (
                self.intercept_rates[-50:]
                if len(self.intercept_rates) >= 50
                else self.intercept_rates
            )
            avg_ir = np.mean(recent) if recent else 0
            print(
                f"  [Step {self.num_timesteps:>7d}] Episodes: {len(self.intercept_rates)} "
                f"| avg intercept_rate: {avg_ir:.1%}",
                flush=True,
            )
        return True


def main():
    device = detect_best_device()
    print("=" * 70)
    print("PMTEC DQN 200K Training - Fresh Model (v2)")
    print(f"Device: {device}")
    if "xpu" in device:
        print(f"  GPU: {torch.xpu.get_device_name(0)}")
        print(
            f"  Memory: {torch.xpu.get_device_properties(0).total_memory / 1e9:.2f} GB"
        )
    print(f"  Target: 200000 timesteps")
    print(f"  Checkpoint interval: 50000 steps")
    print(f"  Logging: every 10000 steps (minimal I/O)")
    print("=" * 70, flush=True)

    # Create environment
    env = PMTECEnv(duration=120, seed=42)
    vec_env = DummyVecEnv([lambda: env])
    print(
        f"Environment: obs_dim={env.observation_space.shape[0]} | actions={env.action_space.n}",
        flush=True,
    )

    # Create fresh DQN model with optimized hyperparameters
    policy_kwargs = {
        "net_arch": [128, 64],
        "activation_fn": nn.ReLU,
    }

    model = DQN(
        "MlpPolicy",
        vec_env,
        learning_rate=1e-4,
        buffer_size=50000,  # Larger buffer for longer training
        batch_size=128,  # Larger batch for better gradient estimates
        gamma=0.95,
        exploration_fraction=0.15,  # Faster exploration decay (15% of 200K = 30K)
        exploration_initial_eps=0.5,  # Start with some exploitation
        exploration_final_eps=0.02,
        target_update_interval=500,
        train_freq=4,
        policy_kwargs=policy_kwargs,
        device=device,
        verbose=0,  # Disable SB3 logging for speed
    )
    print("DQN model created. Starting training...", flush=True)
    print(flush=True)

    # Checkpoint callback
    checkpoint_cb = CheckpointCallback(
        save_freq=50000,
        save_path=_MODEL_DIR,
        name_prefix="pmtec_dqn_200k_ckpt",
        save_replay_buffer=False,
        save_vecnormalize=False,
    )

    # Progress logger
    progress_cb = ProgressCallback()

    # Train
    t0 = time.time()
    model.learn(
        total_timesteps=200000,
        callback=[checkpoint_cb, progress_cb],
        reset_num_timesteps=True,  # Correct: reset to 0, target is 200K
        progress_bar=False,
    )
    elapsed = time.time() - t0

    # Save final model
    model.save(FINAL_MODEL)
    print(f"\nFinal model saved: {FINAL_MODEL}", flush=True)
    print(f"Training elapsed: {elapsed:.1f}s ({elapsed / 60:.1f} min)", flush=True)

    # Evaluation
    print("\nEvaluating (5 episodes, deterministic)...", flush=True)
    eval_results = []
    for ep in range(5):
        obs, _ = env.reset(seed=200 + ep)
        total_reward = 0.0
        done = False
        info = {}
        while not done:
            action, _ = model.predict(obs, deterministic=True)
            if hasattr(action, "item"):
                action = action.item()
            elif hasattr(action, "__len__"):
                action = int(action.flat[0])
            obs, reward, done, _, info = env.step(action)
            total_reward += reward
        eval_results.append(
            {
                "episode": ep,
                "total_reward": round(total_reward, 2),
                "intercept_rate": round(info.get("intercept_rate", 0), 3),
                "survived": info.get("active_aircraft", 0),
                "intercepted": info.get("intercepted_missiles", 0),
            }
        )
        print(
            f"  Ep {ep}: reward={total_reward:.1f}, ir={info.get('intercept_rate', 0):.1%}",
            flush=True,
        )

    avg_reward = float(np.mean([r["total_reward"] for r in eval_results]))
    avg_ir = float(np.mean([r["intercept_rate"] for r in eval_results]))
    print(f"\n  AVG: reward={avg_reward:.1f}, intercept_rate={avg_ir:.1%}", flush=True)

    # Save history
    history = {
        "total_timesteps": 200000,
        "elapsed_seconds": round(elapsed, 1),
        "device": device,
        "learning_rate": 1e-4,
        "batch_size": 128,
        "buffer_size": 50000,
        "exploration_initial_eps": 0.5,
        "exploration_final_eps": 0.02,
        "final_avg_reward": round(avg_reward, 2),
        "final_avg_intercept_rate": round(avg_ir, 4),
        "eval_results": eval_results,
        "saved_model": FINAL_MODEL,
    }
    with open(HISTORY_PATH, "w", encoding="utf-8") as f:
        json.dump(history, f, indent=2, ensure_ascii=False)
    print(f"\nHistory saved: {HISTORY_PATH}", flush=True)
    print("=" * 70, flush=True)
    print("DQN 200K training complete!", flush=True)
    print(f"  Model: {FINAL_MODEL}", flush=True)
    print(f"  Avg reward: {avg_reward:.1f}", flush=True)
    print(f"  Avg intercept rate: {avg_ir:.1%}", flush=True)
    print("=" * 70, flush=True)


if __name__ == "__main__":
    main()
